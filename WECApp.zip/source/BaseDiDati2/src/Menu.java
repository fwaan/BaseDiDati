import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.jface.resource.LocalResourceManager;
import org.eclipse.jface.resource.JFaceResources;
import org.eclipse.jface.resource.FontDescriptor;
import org.eclipse.swt.widgets.Label;

public class Menu {

	protected Shell shlCampionato;
	private LocalResourceManager localResourceManager;
	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			Menu window = new Menu();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shlCampionato.open();
		shlCampionato.layout();
		while (!shlCampionato.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shlCampionato = new Shell();
		createResourceManager();
		shlCampionato.setImage(null);
		shlCampionato.setSize(805, 753);
		shlCampionato.setText("Campionato automobilistico");
		
		Button btnNewButton = new Button(shlCampionato, SWT.NONE);
		btnNewButton.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 9, SWT.NORMAL)));
		btnNewButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				ScuderiaRegistrationWindow();
			}
		});
		btnNewButton.setBounds(10, 48, 769, 32);
		btnNewButton.setText("1 - Registrazione di una scuderia");
		
		Button btnNewButton_1 = new Button(shlCampionato, SWT.NONE);
		btnNewButton_1.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				vetturaWindow();
			}
		});
		btnNewButton_1.setText("2 - Inserimento dei dati di un’autovettura, compresi i componenti");
		btnNewButton_1.setBounds(10, 88, 769, 32);
		
		Button btnNewButton_2 = new Button(shlCampionato, SWT.NONE);
		btnNewButton_2.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				aggiuntaPilota();
			}
		});
		btnNewButton_2.setText("3 - Aggiunta di un nuovo pilota");
		btnNewButton_2.setBounds(10, 126, 769, 32);
		
		Button btnNewButton_3 = new Button(shlCampionato, SWT.NONE);
		btnNewButton_3.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				registraFinanziamento();
			}
		});
		btnNewButton_3.setText("4 - Registrazione di un finanziamento per una scuderia");
		btnNewButton_3.setBounds(10, 164, 769, 32);
		
		Button btnNewButton_4 = new Button(shlCampionato, SWT.NONE);
		btnNewButton_4.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				iscrizioneGara();
			}
		});
		btnNewButton_4.setText("5 - Iscrizione di una vettura ad una gara");
		btnNewButton_4.setBounds(10, 202, 769, 32);
		
		Button btnNewButton_4_1 = new Button(shlCampionato, SWT.NONE);
		btnNewButton_4_1.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				risultatoVettura();
			}
		});
		btnNewButton_4_1.setText("6 - Registrazione del risultato conseguito dalla vettura");
		btnNewButton_4_1.setBounds(10, 240, 769, 32);
		
		Button btnNewButton_4_2 = new Button(shlCampionato, SWT.NONE);
		btnNewButton_4_2.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				verificaMontaComponente();
			}
		});
		btnNewButton_4_2.setText("7 - Verifica della possibilità di montare un componente su una vettura");
		btnNewButton_4_2.setBounds(10, 278, 769, 32);
		
		Button btnNewButton_4_3 = new Button(shlCampionato, SWT.NONE);
		btnNewButton_4_3.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				controllaFinanziamenti();
			}
		});
		btnNewButton_4_3.setText("8 - Stampa finanziamenti delle scuderie");
		btnNewButton_4_3.setBounds(10, 316, 769, 32);
		
		Button btnNewButton_4_4 = new Button(shlCampionato, SWT.NONE);
		btnNewButton_4_4.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				stampaScuderieAnnuale();
			}
		});
		btnNewButton_4_4.setText("9 - Stampa scuderie compreso il numero di finanziamenti ricevuti");
		btnNewButton_4_4.setBounds(10, 354, 769, 32);
		
		Button btnNewButton_4_5 = new Button(shlCampionato, SWT.NONE);
		btnNewButton_4_5.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				stampaPilotiCircuitoCasa();
			}
		});
		btnNewButton_4_5.setText("10 - Visualizza i piloti che hanno vinto nel «circuito di casa»");
		btnNewButton_4_5.setBounds(10, 392, 769, 32);
		
		Button btnNewButton_4_6 = new Button(shlCampionato, SWT.NONE);
		btnNewButton_4_6.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				gentleManPercent();
			}
		});
		btnNewButton_4_6.setText("11 - Visualizza percentuale di Genteman nell'equipaggio");
		btnNewButton_4_6.setBounds(10, 430, 769, 32);
		
		Button btnNewButton_4_7 = new Button(shlCampionato, SWT.NONE);
		btnNewButton_4_7.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				stampaCostruttoriComponenti();
			}
		});
		btnNewButton_4_7.setText("12 - Stampa dei costruttori compreso il numero di componenti forniti");
		btnNewButton_4_7.setBounds(10, 468, 769, 32);
		
		Button btnNewButton_4_8 = new Button(shlCampionato, SWT.NONE);
		btnNewButton_4_8.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				stampaClassificaVetture();
			}
		});
		btnNewButton_4_8.setText("13 - Stampa della classifica finale dei punti conseguiti da tutte le vetture");
		btnNewButton_4_8.setBounds(10, 506, 769, 32);
		
		Button btnNewButton_4_9 = new Button(shlCampionato, SWT.NONE);
		btnNewButton_4_9.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				stampaClassificaVettureMotore();
			}
		});
		btnNewButton_4_9.setText("14 - Stampa delle classifiche finali di punti per tipo di motore");
		btnNewButton_4_9.setBounds(10, 544, 769, 32);
		
		Button btnNewButton_4_10 = new Button(shlCampionato, SWT.NONE);
		btnNewButton_4_10.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				stampaPuntiMinuti();
			}
		});
		btnNewButton_4_10.setText("15 - Report scuderie punti/minuto");
		btnNewButton_4_10.setBounds(10, 582, 769, 32);
		
		Button btnNewButton_4_11 = new Button(shlCampionato, SWT.NONE);
		btnNewButton_4_11.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				shlCampionato.close();
				Display.getDefault().dispose();
				System.exit(0);
			}
		});
		btnNewButton_4_11.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 14, SWT.BOLD)));
		btnNewButton_4_11.setText("ESCI");
		btnNewButton_4_11.setBounds(10, 658, 769, 46);
		
		Label lblMenuPerLe = new Label(shlCampionato, SWT.NONE);
		lblMenuPerLe.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 13, SWT.BOLD)));
		lblMenuPerLe.setAlignment(SWT.CENTER);
		lblMenuPerLe.setBounds(10, 10, 769, 32);
		lblMenuPerLe.setText("MENU");
		
		Button btnNewButton_4_10_1 = new Button(shlCampionato, SWT.NONE);
		btnNewButton_4_10_1.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				inserisciCostruttori();
			}
		});
		btnNewButton_4_10_1.setText("EXTRA - Inserisci costruttore");
		btnNewButton_4_10_1.setBounds(10, 620, 769, 32);

	}
	private void createResourceManager() {
		localResourceManager = new LocalResourceManager(JFaceResources.getResources(),shlCampionato);
	}
	private void ScuderiaRegistrationWindow() {
		query1.main(null);
    }
	private void vetturaWindow() {
		query2.main(null);
	}
	private void aggiuntaPilota() {
		query3.main(null);
	}
	private void registraFinanziamento() {
		query4.main(null);
	}
	private void iscrizioneGara() {
		query5.main(null);
	}
	private void risultatoVettura() {
		query6.main(null);
	}
	private void verificaMontaComponente() {
		query7.main(null);
	}
	private void controllaFinanziamenti() {
		query8.main(null);
	}
	private void stampaScuderieAnnuale() {
		query9.main(null);
	}
	private void stampaPilotiCircuitoCasa() {
		query10.main(null);
	}
	private void gentleManPercent() {
		query11.main(null);
	}
	private void stampaCostruttoriComponenti() {
		query12.main(null);
	}
	private void stampaClassificaVetture() {
		query13.main(null);
	}
	private void stampaClassificaVettureMotore() {
		query14.main(null);
	}
	private void stampaPuntiMinuti() {
		query15.main(null);
	}
	private void inserisciCostruttori() {
		query16_extra.main(null);
	}
}