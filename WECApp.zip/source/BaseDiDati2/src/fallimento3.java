import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.SWT;
import org.eclipse.jface.resource.LocalResourceManager;
import org.eclipse.jface.resource.JFaceResources;
import org.eclipse.jface.resource.FontDescriptor;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Label;

public class fallimento3 {

	protected Shell shellfallimento3;
	private LocalResourceManager localResourceManager;

	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			fallimento3 window = new fallimento3();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shellfallimento3.open();
		shellfallimento3.layout();
		while (!shellfallimento3.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shellfallimento3 = new Shell();
		createResourceManager();
		shellfallimento3.setSize(1192, 339);
		
		Button btnNewButton = new Button(shellfallimento3, SWT.NONE);
		btnNewButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				shellfallimento3.close();
			}
		});
		btnNewButton.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 52, SWT.BOLD)));
		btnNewButton.setBounds(10, 165, 1156, 125);
		btnNewButton.setText("CHIUDI");
		
		Label lblOperazioneFallita = new Label(shellfallimento3, SWT.NONE);
		lblOperazioneFallita.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 24, SWT.BOLD)));
		lblOperazioneFallita.setAlignment(SWT.CENTER);
		lblOperazioneFallita.setBounds(10, 10, 1156, 149);
		lblOperazioneFallita.setText("OPERAZIONE FALLITA : PILOTA ESISTENTE O SCUDERIA/VETTURA INESISTENTE");

	}
	private void createResourceManager() {
		localResourceManager = new LocalResourceManager(JFaceResources.getResources(),shellfallimento3);
	}
}
