import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.SWT;
import org.eclipse.jface.resource.LocalResourceManager;
import org.eclipse.jface.resource.JFaceResources;
import org.eclipse.jface.resource.FontDescriptor;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Label;

public class fallimento3_1 {

	protected Shell shellfallimento3;
	private LocalResourceManager localResourceManager;

	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			fallimento3_1 window = new fallimento3_1();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shellfallimento3.open();
		shellfallimento3.layout();
		while (!shellfallimento3.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shellfallimento3 = new Shell();
		createResourceManager();
		shellfallimento3.setSize(1281, 450);
		
		Button btnNewButton = new Button(shellfallimento3, SWT.NONE);
		btnNewButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				shellfallimento3.close();
			}
		});
		btnNewButton.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 52, SWT.BOLD)));
		btnNewButton.setBounds(10, 276, 1245, 125);
		btnNewButton.setText("CHIUDI");
		
		Label lblOperazioneFallita = new Label(shellfallimento3, SWT.NONE);
		lblOperazioneFallita.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 24, SWT.BOLD)));
		lblOperazioneFallita.setAlignment(SWT.CENTER);
		lblOperazioneFallita.setBounds(10, 10, 1245, 260);
		lblOperazioneFallita.setText("OPERAZIONE FALLITA : IL PRIMO PILOTA DI UNA SCUDERIA NON PUO' ESSERE GM");

	}
	private void createResourceManager() {
		localResourceManager = new LocalResourceManager(JFaceResources.getResources(),shellfallimento3);
	}
}
