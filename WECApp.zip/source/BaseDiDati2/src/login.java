import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.SWT;
import org.eclipse.jface.resource.LocalResourceManager;
import org.eclipse.jface.resource.JFaceResources;


import org.eclipse.jface.resource.FontDescriptor;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.ModifyEvent;

public class login {

	public static String databaseName;
	public static String databaseUsername;
	public static String databasePassword;
	private Database basedati;
	protected static Shell shelllogin;
	private LocalResourceManager localResourceManager;
	private final FormToolkit formToolkit = new FormToolkit(Display.getDefault());
	private Text nomedatabasetxt;
	private Text usernomedatabasetxt;
	private Text passworddatabasetxt;

	public static void main(String[] args) {
		try {
			if(shelllogin == null || shelllogin.isDisposed())
			{
				/**
				 * Launch the application.
				 * @param args
				 * @wbp.parser.entryPoint
				 */
				login window = new login();
				window.open();
			}
			else {
				shelllogin.forceActive();
				shelllogin.setMinimized(false);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 * @wbp.parser.entryPoint
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shelllogin.open();
		shelllogin.layout();
		while (!shelllogin.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 * @wbp.parser.entryPoint
	 */
	protected void createContents() {
		shelllogin = new Shell();
		createResourceManager();
		shelllogin.setImage(null);
		shelllogin.setSize(750, 356);
		
		Label lblAccessoDatabase = new Label(shelllogin, SWT.NONE);
		lblAccessoDatabase.setAlignment(SWT.CENTER);
		lblAccessoDatabase.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 24, SWT.BOLD)));
		lblAccessoDatabase.setBounds(10, 0, 714, 61);
		lblAccessoDatabase.setText("ACCESSO DATABASE");
		
		Label lblnomedatabase = new Label(shelllogin, SWT.NONE);
		lblnomedatabase.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 11, SWT.BOLD)));
		lblnomedatabase.setBounds(37, 67, 166, 35);
		formToolkit.adapt(lblnomedatabase, true, true);
		lblnomedatabase.setText("NOME");
		
		Label lblusernomedatabase = new Label(shelllogin, SWT.NONE);
		lblusernomedatabase.setText("USERNAME");
		lblusernomedatabase.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 11, SWT.BOLD)));
		lblusernomedatabase.setBounds(37, 104, 166, 35);
		formToolkit.adapt(lblusernomedatabase, true, true);
		
		nomedatabasetxt = new Text(shelllogin, SWT.BORDER);
		
		nomedatabasetxt.setBounds(209, 67, 515, 35);
		formToolkit.adapt(nomedatabasetxt, true, true);
		
		usernomedatabasetxt = new Text(shelllogin, SWT.BORDER);
		usernomedatabasetxt.setBounds(209, 105, 515, 34);
		formToolkit.adapt(usernomedatabasetxt, true, true);
		
		Button btnAccedi = new Button(shelllogin, SWT.NONE);
		btnAccedi.setEnabled(false);
		btnAccedi.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				accessoFunzione();
			}
		});
		btnAccedi.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 26, SWT.BOLD)));
		btnAccedi.setBounds(10, 189, 714, 118);
		formToolkit.adapt(btnAccedi, true, true);
		btnAccedi.setText("ACCEDI");
		
		Label lblpassworddatabase = new Label(shelllogin, SWT.NONE);
		lblpassworddatabase.setText("PASSWORD");
		lblpassworddatabase.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 11, SWT.BOLD)));
		lblpassworddatabase.setBounds(37, 148, 166, 35);
		formToolkit.adapt(lblpassworddatabase, true, true);
		
		passworddatabasetxt = new Text(shelllogin, SWT.BORDER);
		passworddatabasetxt.setBounds(209, 147, 515, 36);
		formToolkit.adapt(passworddatabasetxt, true, true);
		
		nomedatabasetxt.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				databaseName = nomedatabasetxt.getText();
				if(!nomedatabasetxt.getText().isEmpty() && !usernomedatabasetxt.getText().isEmpty() && !passworddatabasetxt.getText().isEmpty()) btnAccedi.setEnabled(true);
				if(nomedatabasetxt.getText().isEmpty()) btnAccedi.setEnabled(false);
			}
		});
		usernomedatabasetxt.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				databaseUsername = usernomedatabasetxt.getText();
				if(!nomedatabasetxt.getText().isEmpty() && !usernomedatabasetxt.getText().isEmpty() && !passworddatabasetxt.getText().isEmpty()) btnAccedi.setEnabled(true);
				if(usernomedatabasetxt.getText().isEmpty()) btnAccedi.setEnabled(false);
			}
		});
		passworddatabasetxt.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				databasePassword = passworddatabasetxt.getText();
				if(!nomedatabasetxt.getText().isEmpty() && !usernomedatabasetxt.getText().isEmpty() && !passworddatabasetxt.getText().isEmpty()) btnAccedi.setEnabled(true);
				if(passworddatabasetxt.getText().isEmpty()) btnAccedi.setEnabled(false);
			}
		});

	}
	/**
	 * @wbp.parser.entryPoint
	 */
	private void createResourceManager() {
		localResourceManager = new LocalResourceManager(JFaceResources.getResources(),shelllogin);
	}
	private void accessoFunzione(){
	    try {
	    	basedati = new Database(databaseName,databaseUsername,databasePassword);
	    	basedati.connect();
	    	if(basedati.getConnection() != null) {
	    		shelllogin.setVisible(false);
	    		Menu.main(null);
	    		System.exit(0);
	    	}
	    	else {
	    		fallimentologin.main(null);
	    	}
	    } catch(Exception e) {
	        e.printStackTrace();
	    }
	}
}
