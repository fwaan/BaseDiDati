import java.sql.*;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.SWT;
import org.eclipse.jface.resource.LocalResourceManager;
import org.eclipse.jface.resource.JFaceResources;
import org.eclipse.jface.resource.FontDescriptor;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.ModifyEvent;

public class query1 {
	
	private Database basedati;
	protected static Shell shell1;
	private LocalResourceManager localResourceManager;
	private final FormToolkit formToolkit = new FormToolkit(Display.getDefault());
	private Text codicescuderiatxt;
	private Text nomescuderiatxt;
	private Text paesescuderiatxt;

	public static void main(String[] args) {
		try {
			if(shell1 == null || shell1.isDisposed())
			{
				/**
				 * Launch the application.
				 * @param args
				 * @wbp.parser.entryPoint
				 */
				query1 window = new query1();
				window.open();
			}
			else {
				shell1.forceActive();
				shell1.setMinimized(false);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 * @wbp.parser.entryPoint
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell1.open();
		shell1.layout();
		while (!shell1.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 * @wbp.parser.entryPoint
	 */
	protected void createContents() {
		shell1 = new Shell();
		createResourceManager();
		shell1.setImage(null);
		shell1.setSize(750, 320);
		
		Label lblRegistrazioneScuderia = new Label(shell1, SWT.NONE);
		lblRegistrazioneScuderia.setAlignment(SWT.CENTER);
		lblRegistrazioneScuderia.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 24, SWT.BOLD)));
		lblRegistrazioneScuderia.setBounds(10, 10, 714, 61);
		lblRegistrazioneScuderia.setText("REGISTRAZIONE SCUDERIA");
		
		Label lblCodiceScuderia = new Label(shell1, SWT.NONE);
		lblCodiceScuderia.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 11, SWT.BOLD)));
		lblCodiceScuderia.setBounds(10, 77, 193, 32);
		formToolkit.adapt(lblCodiceScuderia, true, true);
		lblCodiceScuderia.setText("CODICE SCUDERIA");
		
		Label lblNomeScuderia = new Label(shell1, SWT.NONE);
		lblNomeScuderia.setText("NOME SCUDERIA");
		lblNomeScuderia.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 11, SWT.BOLD)));
		lblNomeScuderia.setBounds(10, 115, 193, 32);
		formToolkit.adapt(lblNomeScuderia, true, true);
		
		Label lblPaeseScuderia = new Label(shell1, SWT.NONE);
		lblPaeseScuderia.setText("PAESE SCUDERIA");
		lblPaeseScuderia.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 11, SWT.BOLD)));
		lblPaeseScuderia.setBounds(10, 153, 193, 32);
		formToolkit.adapt(lblPaeseScuderia, true, true);
		
		codicescuderiatxt = new Text(shell1, SWT.BORDER);
		
		codicescuderiatxt.setBounds(209, 78, 515, 32);
		formToolkit.adapt(codicescuderiatxt, true, true);
		
		nomescuderiatxt = new Text(shell1, SWT.BORDER);
		
		nomescuderiatxt.setBounds(209, 116, 515, 32);
		formToolkit.adapt(nomescuderiatxt, true, true);
		
		paesescuderiatxt = new Text(shell1, SWT.BORDER);
		
		paesescuderiatxt.setBounds(209, 154, 515, 32);
		formToolkit.adapt(paesescuderiatxt, true, true);
		
		Button btnRegistraScuderia = new Button(shell1, SWT.NONE);
		btnRegistraScuderia.setEnabled(false);
		btnRegistraScuderia.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				registraScuderiaBottoneFunzione();
			}
		});
		btnRegistraScuderia.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 26, SWT.BOLD)));
		btnRegistraScuderia.setBounds(10, 191, 714, 80);
		formToolkit.adapt(btnRegistraScuderia, true, true);
		btnRegistraScuderia.setText("REGISTRA");
		codicescuderiatxt.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				if(!codicescuderiatxt.getText().isEmpty() && !nomescuderiatxt.getText().isEmpty() && !paesescuderiatxt.getText().isEmpty()) btnRegistraScuderia.setEnabled(true);
				if(codicescuderiatxt.getText().isEmpty() && !nomescuderiatxt.getText().isEmpty() && !paesescuderiatxt.getText().isEmpty()) btnRegistraScuderia.setEnabled(false);
			}
		});
		nomescuderiatxt.addModifyListener(new ModifyListener() {
			@Override
			public void modifyText(ModifyEvent e) {
				if(!codicescuderiatxt.getText().isEmpty() && !nomescuderiatxt.getText().isEmpty() && !paesescuderiatxt.getText().isEmpty()) btnRegistraScuderia.setEnabled(true);
				if(!codicescuderiatxt.getText().isEmpty() && nomescuderiatxt.getText().isEmpty() && !paesescuderiatxt.getText().isEmpty()) btnRegistraScuderia.setEnabled(false);
			}
		});
		paesescuderiatxt.addModifyListener(new ModifyListener() {
			@Override
			public void modifyText(ModifyEvent e) {
				if(!codicescuderiatxt.getText().isEmpty() && !nomescuderiatxt.getText().isEmpty() && !paesescuderiatxt.getText().isEmpty()) btnRegistraScuderia.setEnabled(true);
				if(!codicescuderiatxt.getText().isEmpty() && !nomescuderiatxt.getText().isEmpty() && paesescuderiatxt.getText().isEmpty()) btnRegistraScuderia.setEnabled(false);
			}
		});

	}
	/**
	 * @wbp.parser.entryPoint
	 */
	private void createResourceManager() {
		localResourceManager = new LocalResourceManager(JFaceResources.getResources(),shell1);
	}
	private void registraScuderiaBottoneFunzione(){
		try {
			int controlloquery1;
			PreparedStatement preparedstatement;
			basedati = new Database(login.databaseName,login.databaseUsername,login.databasePassword);
			basedati.connect();
			preparedstatement = basedati.getConnection().prepareStatement("INSERT INTO basedidati.scuderia (codice, nome, paese, finanziamenti) VALUES ('"+codicescuderiatxt.getText()+"', '"+nomescuderiatxt.getText()+"', '"+paesescuderiatxt.getText()+"', '0');");
			controlloquery1 = preparedstatement.executeUpdate();
			if(controlloquery1>0) {
				successo.main(null);
			}
			preparedstatement.close();
			basedati.close();
		}catch(SQLIntegrityConstraintViolationException e){
			fallimento1.main(null);
		}catch(Exception e) {
			fallimento4_1.main(null);
		}
	}
}
