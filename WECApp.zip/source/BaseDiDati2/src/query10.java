import javax.swing.*;
import java.awt.*;
import javax.swing.table.DefaultTableModel;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLIntegrityConstraintViolationException;

public class query10 extends JFrame {
    private static final long serialVersionUID = 1L;
    private Database basedati;

    public static void main(String[] args) {
        new query10();
    }
    
    public query10() {
        setLayout(new BorderLayout());

        // Crea un modello di tabella
        DefaultTableModel model = new DefaultTableModel(new String[]{"Codice Pilota","Nome Pilota", "Cognome Pilota", "Modello Vettura", "Nome Gara", "Paese Circuito"}, 0){
            private static final long serialVersionUID = 3L;
            @Override
            public boolean isCellEditable(int row, int column) {
                // Tutte le celle non sono modificabili
                return false;
            }
        };

        // Crea una tabella con il modello
        JTable table = new JTable(model);

        // Aggiungi la tabella a uno JScrollPane
        add(new JScrollPane(table), BorderLayout.CENTER);
        pack();
        setVisible(false);

        try {
            PreparedStatement preparedstatement;
            basedati = new Database(login.databaseName,login.databaseUsername,login.databasePassword);
            basedati.connect();

            // Prepara la query
            String query = "SELECT pilota.codice AS codice_pilota, pilota.nome, pilota.cognome, vettura.modello, gara.nome, circuito.paese " +
                    "FROM pilota " +
                    "JOIN origine ON pilota.codice = origine.codice_pilota " +
                    "JOIN nazionalita ON origine.nome_nazionalita = nazionalita.nome " +
                    "JOIN vettura ON pilota.codice_vettura = vettura.codice " +
                    "JOIN iscrizione ON vettura.codice = iscrizione.codice_vettura " +
                    "JOIN gara ON iscrizione.codice_gara = gara.codice " +
                    "JOIN circuito ON gara.codice_circuito = circuito.codice " +
                    "WHERE iscrizione.punti = (SELECT MAX(iscrizione.punti) FROM iscrizione WHERE iscrizione.codice_gara = gara.codice) " +
                    "AND circuito.paese = nazionalita.nome";
            preparedstatement = basedati.getConnection().prepareStatement(query);

            // Esegui la query
            ResultSet rs = preparedstatement.executeQuery();

            // Controlla se la query ha restituito almeno una riga
            if (rs.next()) {
                setVisible(true);
                do {
                    model.addRow(new Object[]{rs.getString("codice_pilota"), rs.getString("pilota.nome"), rs.getString("pilota.cognome"), rs.getString("vettura.modello"), rs.getString("gara.nome"), rs.getString("circuito.paese")});
                } while (rs.next());
            } else {
                fallimento10.main(null);
            }

            // Chiudi il ResultSet e il PreparedStatement
            rs.close();
            preparedstatement.close();
        } catch(SQLIntegrityConstraintViolationException e){
            fallimento10.main(null);
        } catch(Exception e) {
        	fallimento4_1.main(null);
            e.printStackTrace();
        }
    }
}