import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.SWT;
import org.eclipse.jface.resource.LocalResourceManager;
import org.eclipse.jface.resource.JFaceResources;
import org.eclipse.jface.resource.FontDescriptor;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Button;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.ModifyEvent;

public class query11 {

	private Database basedati;
	protected static Shell shell11;
	private LocalResourceManager localResourceManager;
	private final FormToolkit formToolkit = new FormToolkit(Display.getDefault());
	private Text codicescuderiacontrollotxt;

	public static void main(String[] args) {
		try {
			if(shell11 == null || shell11.isDisposed())
			{
				/**
				 * Launch the application.
				 * @param args
				 * @wbp.parser.entryPoint
				 */
				query11 window = new query11();
				window.open();
			}
			else {
				shell11.forceActive();
				shell11.setMinimized(false);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 * @wbp.parser.entryPoint
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell11.open();
		shell11.layout();
		while (!shell11.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 * @wbp.parser.entryPoint
	 */
	protected void createContents() {
		shell11 = new Shell();
		createResourceManager();
		shell11.setImage(null);
		shell11.setSize(750, 517);
		
		Label lblFinanziamentiRicevuti = new Label(shell11, SWT.NONE);
		lblFinanziamentiRicevuti.setAlignment(SWT.CENTER);
		lblFinanziamentiRicevuti.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 24, SWT.BOLD)));
		lblFinanziamentiRicevuti.setBounds(10, 10, 714, 184);
		lblFinanziamentiRicevuti.setText("CONTROLLO GENTLEMAN DRIVER");
		
		Label lblCodiceScuderia = new Label(shell11, SWT.NONE);
		lblCodiceScuderia.setAlignment(SWT.CENTER);
		lblCodiceScuderia.setText("CODICE SCUDERIA");
		lblCodiceScuderia.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 11, SWT.BOLD)));
		lblCodiceScuderia.setBounds(10, 200, 714, 32);
		formToolkit.adapt(lblCodiceScuderia, true, true);
		
		codicescuderiacontrollotxt = new Text(shell11, SWT.BORDER);
		codicescuderiacontrollotxt.setBounds(10, 238, 714, 32);
		formToolkit.adapt(codicescuderiacontrollotxt, true, true);
		
		Button btnControlloGM = new Button(shell11, SWT.NONE);
		btnControlloGM.setEnabled(false);
		btnControlloGM.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				risultati();
			}
		});
		btnControlloGM.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 26, SWT.BOLD)));
		btnControlloGM.setBounds(10, 276, 714, 93);
		formToolkit.adapt(btnControlloGM, true, true);
		btnControlloGM.setText("CONTROLLA");
		
		Button btnControllaTutto = new Button(shell11, SWT.NONE);
		btnControllaTutto.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				risultati1();
			}
		});
		btnControllaTutto.setText("CONTROLLA TUTTO");
		btnControllaTutto.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 26, SWT.BOLD)));
		btnControllaTutto.setBounds(10, 375, 714, 93);
		formToolkit.adapt(btnControllaTutto, true, true);
		codicescuderiacontrollotxt.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				if(!codicescuderiacontrollotxt.getText().isEmpty()) btnControlloGM.setEnabled(true);
				if(codicescuderiacontrollotxt.getText().isEmpty()) btnControlloGM.setEnabled(false);
			}
		});

	}
	/**
	 * @wbp.parser.entryPoint
	 */
	private void createResourceManager() {
		localResourceManager = new LocalResourceManager(JFaceResources.getResources(),shell11);
	}
	private void risultati(){
	    JFrame frame = new JFrame();
	    frame.setLayout(new BorderLayout());

	    // Crea un modello di tabella
	    DefaultTableModel model = new DefaultTableModel(new String[]{"Nome Scuderia", "Percentuale Gentleman Driver"}, 0){
	        private static final long serialVersionUID = 1L;
	        @Override
	        public boolean isCellEditable(int row, int column) {
	            // Tutte le celle non sono modificabili
	            return false;
	        }
	    };

	    // Crea una tabella con il modello
	    JTable table = new JTable(model);

	    // Aggiungi la tabella a uno JScrollPane
	    frame.add(new JScrollPane(table), BorderLayout.CENTER);
	    frame.pack();
	    frame.setVisible(false);

	    try {
	        PreparedStatement preparedstatement;
	        basedati = new Database(login.databaseName,login.databaseUsername,login.databasePassword);
	        basedati.connect();

	        // Prepara la query
	        String query = "SELECT scuderia.nome, (SUM(pilota.gentleman_driver) / COUNT(*)) * 100 AS percentuale_gentleman " +
	                       "FROM pilota " +
	                       "JOIN scuderia ON pilota.codice_scuderia = scuderia.codice " +
	                       "WHERE scuderia.codice = ? " +
	                       "GROUP BY scuderia.nome";
	        preparedstatement = basedati.getConnection().prepareStatement(query);

	        // Imposta i parametri
	        preparedstatement.setString(1, codicescuderiacontrollotxt.getText());

	        // Esegui la query
	        ResultSet rs = preparedstatement.executeQuery();

	        // Controlla se la query ha restituito almeno una riga
	        if (rs.next()) {
	            frame.setVisible(true);
	            do {
	                model.addRow(new Object[]{rs.getString("nome"), rs.getFloat("percentuale_gentleman")+"%"});
	            } while (rs.next());
	        } else {
	            fallimento11.main(null);
	        }

	        // Chiudi il ResultSet e il PreparedStatement
	        rs.close();
	        preparedstatement.close();
	    } catch(SQLIntegrityConstraintViolationException e){
	        fallimento11.main(null);
	    } catch(Exception e) {
	        e.printStackTrace();
	    }
	}
	private void risultati1(){
	    JFrame frame = new JFrame();
	    frame.setLayout(new BorderLayout());

	    // Crea un modello di tabella
	    DefaultTableModel model = new DefaultTableModel(new String[]{"Codice Scuderia", "Nome Scuderia", "Percentuale Gentleman Driver"}, 0){
	        private static final long serialVersionUID = 1L;
	        @Override
	        public boolean isCellEditable(int row, int column) {
	            // Tutte le celle non sono modificabili
	            return false;
	        }
	    };

	    // Crea una tabella con il modello
	    JTable table = new JTable(model);

	    // Aggiungi la tabella a uno JScrollPane
	    frame.add(new JScrollPane(table), BorderLayout.CENTER);
	    frame.pack();
	    frame.setVisible(false);

	    try {
	        PreparedStatement preparedstatement;
	        basedati = new Database(login.databaseName,login.databaseUsername,login.databasePassword);
	        basedati.connect();

	        // Prepara la query
	        String query = "SELECT scuderia.codice, scuderia.nome, (SUM(pilota.gentleman_driver) / COUNT(*)) * 100 AS percentuale_gentleman " +
	                       "FROM pilota " +
	                       "JOIN scuderia ON pilota.codice_scuderia = scuderia.codice " +
	                       "GROUP BY scuderia.codice, scuderia.nome";
	        preparedstatement = basedati.getConnection().prepareStatement(query);

	        // Esegui la query
	        ResultSet rs = preparedstatement.executeQuery();

	        // Controlla se la query ha restituito almeno una riga
	        if (rs.next()) {
	            frame.setVisible(true);
	            do {
	                model.addRow(new Object[]{rs.getString("codice"), rs.getString("nome"), rs.getFloat("percentuale_gentleman")+"%"});
	            } while (rs.next());
	        } else {
	            fallimento9.main(null);
	        }

	        // Chiudi il ResultSet e il PreparedStatement
	        rs.close();
	        preparedstatement.close();
	    } catch(SQLIntegrityConstraintViolationException e){
	        fallimento9.main(null);
	    } catch(Exception e) {
	    	fallimento4_1.main(null);
	        e.printStackTrace();
	    }
	}
}
