import javax.swing.*;
import java.awt.*;
import javax.swing.table.DefaultTableModel;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLIntegrityConstraintViolationException;

public class query12 extends JFrame {
    private static final long serialVersionUID = 1L;
    private Database basedati;

    public static void main(String[] args) {
        new query12();
    }
    
    public query12() {
        setLayout(new BorderLayout());

        // Crea un modello di tabella
        DefaultTableModel model = new DefaultTableModel(new String[]{"Nome Costruttore", "Sede Fabbrica", "Ragione Sociale", "Numero Componenti"}, 0){
            private static final long serialVersionUID = 2L;
            @Override
            public boolean isCellEditable(int row, int column) {
                // Tutte le celle non sono modificabili
                return false;
            }
        };

        // Crea una tabella con il modello
        JTable table = new JTable(model);

        // Aggiungi la tabella a uno JScrollPane
        add(new JScrollPane(table), BorderLayout.CENTER);
        pack();
        setVisible(false);

        try {
            PreparedStatement preparedstatement;
            basedati = new Database(login.databaseName,login.databaseUsername,login.databasePassword);
            basedati.connect();

            // Calcola il numero di componenti per ogni costruttore
            String query = "SELECT costruttore.nome AS nome_costruttore, costruttore.sede_fabbrica, costruttore.ragione_sociale, COUNT(componente.nome_costruttore) AS num_componenti " +
                    "FROM costruttore " +
                    "LEFT JOIN componente ON costruttore.nome = componente.nome_costruttore AND costruttore.sede_fabbrica = componente.sede_fabbrica " +
                    "GROUP BY costruttore.nome, costruttore.sede_fabbrica, costruttore.ragione_sociale";
            preparedstatement = basedati.getConnection().prepareStatement(query);

            // Esegui la query
            ResultSet rs = preparedstatement.executeQuery();

            // Per ogni costruttore, aggiorna il numero di componenti
            while (rs.next()) {
                String nomeCostruttore = rs.getString("nome_costruttore");
                String sedeFabbrica = rs.getString("sede_fabbrica");
                String ragioneSociale = rs.getString("ragione_sociale");
                int numComponenti = rs.getInt("num_componenti");

                // Aggiungi la riga alla tabella
                model.addRow(new Object[]{nomeCostruttore, sedeFabbrica, ragioneSociale, numComponenti});

                // Prepara la query di aggiornamento
                String updateQuery = "UPDATE costruttore " +
                                     "SET componenti = ? " +
                                     "WHERE nome = ? AND sede_fabbrica = ?";
                PreparedStatement updateStatement = basedati.getConnection().prepareStatement(updateQuery);

                // Imposta i parametri
                updateStatement.setInt(1, numComponenti);
                updateStatement.setString(2, nomeCostruttore);
                updateStatement.setString(3, sedeFabbrica);

                // Esegui l'aggiornamento
                updateStatement.executeUpdate();

                // Chiudi il PreparedStatement
                updateStatement.close();
            }

            // Se la tabella ha almeno una riga, rendi visibile il frame
            if (model.getRowCount() > 0) {
                setVisible(true);
            } else {
                fallimento12.main(null);
            }

            // Chiudi il ResultSet e il PreparedStatement
            rs.close();
            preparedstatement.close();
        } catch(SQLIntegrityConstraintViolationException e){
            fallimento12.main(null);
        } catch(Exception e) {
        	fallimento4_1.main(null);
            e.printStackTrace();
        }
    }
}