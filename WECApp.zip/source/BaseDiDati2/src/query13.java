import javax.swing.*;
import java.awt.*;
import javax.swing.table.DefaultTableModel;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLIntegrityConstraintViolationException;

public class query13 extends JFrame {
    private static final long serialVersionUID = 1L;
    private Database basedati;

    public static void main(String[] args) {
        new query13();
    }
    
    public query13() {
        setLayout(new BorderLayout());

        // Crea un modello di tabella
        DefaultTableModel model = new DefaultTableModel(new String[]{"Codice", "Modello", "Totale Punti"}, 0){
            private static final long serialVersionUID = 2L;
            @Override
            public boolean isCellEditable(int row, int column) {
                // Tutte le celle non sono modificabili
                return false;
            }
        };

        // Crea una tabella con il modello
        JTable table = new JTable(model);

        // Aggiungi la tabella a uno JScrollPane
        add(new JScrollPane(table), BorderLayout.CENTER);
        pack();
        setVisible(false);

        try {
            PreparedStatement preparedstatement;
            basedati = new Database(login.databaseName,login.databaseUsername,login.databasePassword);
            basedati.connect();

            // Calcola il totale dei punti per ogni vettura e aggiorna il campo "totale_punti"
            String updateQuery = "UPDATE vettura " +
                                 "SET totale_punti = (SELECT SUM(punti) FROM iscrizione WHERE vettura.codice = iscrizione.codice_vettura)";
            preparedstatement = basedati.getConnection().prepareStatement(updateQuery);

            // Esegui l'aggiornamento
            preparedstatement.executeUpdate();

            // Chiudi il PreparedStatement
            preparedstatement.close();

            // Seleziona tutte le vetture e ordina in base al campo "totale_punti" in ordine decrescente
            String selectQuery = "SELECT * FROM vettura ORDER BY totale_punti DESC";
            preparedstatement = basedati.getConnection().prepareStatement(selectQuery);

            // Esegui la query
            ResultSet rs = preparedstatement.executeQuery();

            // Per ogni vettura, aggiorna il numero di punti
            while (rs.next()) {
                String codice = rs.getString("codice");
                String modello = rs.getString("modello");
                int totalePunti = rs.getInt("totale_punti");

                // Aggiungi la riga alla tabella
                model.addRow(new Object[]{codice, modello, totalePunti});
            }

            // Se la tabella ha almeno una riga, rendi visibile il frame
            if (model.getRowCount() > 0) {
                setVisible(true);
            } else {
                fallimento9.main(null);
            }

            // Chiudi il ResultSet e il PreparedStatement
            rs.close();
            preparedstatement.close();
        } catch(SQLIntegrityConstraintViolationException e){
            fallimento9.main(null);
        } catch(Exception e) {
        	fallimento4_1.main(null);
            e.printStackTrace();
        }
    }
}