import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.SWT;
import org.eclipse.jface.resource.LocalResourceManager;
import org.eclipse.jface.resource.JFaceResources;

import java.awt.BorderLayout;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLIntegrityConstraintViolationException;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import org.eclipse.jface.resource.FontDescriptor;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;

public class query14 {

	private Database basedati;
	protected static Shell shell14;
	private LocalResourceManager localResourceManager;
	private final FormToolkit formToolkit = new FormToolkit(Display.getDefault());
	private Text tipomotoretxt;

	public static void main(String[] args) {
		try {
			if(shell14 == null || shell14.isDisposed())
			{
				/**
				 * Launch the application.
				 * @param args
				 * @wbp.parser.entryPoint
				 */
				query14 window = new query14();
				window.open();
			}
			else {
				shell14.forceActive();
				shell14.setMinimized(false);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 * @wbp.parser.entryPoint
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell14.open();
		shell14.layout();
		while (!shell14.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 * @wbp.parser.entryPoint
	 */
	protected void createContents() {
		shell14 = new Shell();
		createResourceManager();
		shell14.setImage(null);
		shell14.setSize(1246, 375);
		
		Label lblClassificaFinalePerTipoMotore = new Label(shell14, SWT.NONE);
		lblClassificaFinalePerTipoMotore.setAlignment(SWT.CENTER);
		lblClassificaFinalePerTipoMotore.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 24, SWT.BOLD)));
		lblClassificaFinalePerTipoMotore.setBounds(10, 10, 1210, 141);
		lblClassificaFinalePerTipoMotore.setText("CLASSIFICA FINALE PER TIPO MOTORE");
		
		Label lblTipoMotore = new Label(shell14, SWT.NONE);
		lblTipoMotore.setAlignment(SWT.CENTER);
		lblTipoMotore.setText("TIPO MOTORE");
		lblTipoMotore.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 11, SWT.BOLD)));
		lblTipoMotore.setBounds(10, 157, 1210, 32);
		formToolkit.adapt(lblTipoMotore, true, true);
		
		tipomotoretxt = new Text(shell14, SWT.BORDER);
		tipomotoretxt.setBounds(10, 195, 1210, 32);
		formToolkit.adapt(tipomotoretxt, true, true);
		
		Button btnStampaTipoMotore = new Button(shell14, SWT.NONE);
		btnStampaTipoMotore.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				risultati();
			}
		});
		btnStampaTipoMotore.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 26, SWT.BOLD)));
		btnStampaTipoMotore.setBounds(10, 233, 1210, 93);
		formToolkit.adapt(btnStampaTipoMotore, true, true);
		btnStampaTipoMotore.setText("STAMPA");

	}
	/**
	 * @wbp.parser.entryPoint
	 */
	private void createResourceManager() {
		localResourceManager = new LocalResourceManager(JFaceResources.getResources(),shell14);
	}
	private void risultati(){
	    JFrame frame = new JFrame();
	    frame.setLayout(new BorderLayout());

	    // Crea un modello di tabella
	    DefaultTableModel model = new DefaultTableModel(new String[]{"Codice", "Modello", "Totale Punti"}, 0){
	        private static final long serialVersionUID = 1L;
	        @Override
	        public boolean isCellEditable(int row, int column) {
	            // Tutte le celle non sono modificabili
	            return false;
	        }
	    };

	    // Crea una tabella con il modello
	    JTable table = new JTable(model);

	    // Aggiungi la tabella a uno JScrollPane
	    frame.add(new JScrollPane(table), BorderLayout.CENTER);
	    frame.pack();
	    frame.setVisible(false);

	    try {
	        PreparedStatement preparedstatement;
	        basedati = new Database(login.databaseName,login.databaseUsername,login.databasePassword);
	        basedati.connect();

	        // Prepara la query
	        String query = "SELECT vettura.codice, vettura.modello, SUM(iscrizione.punti) AS totale_punti " +
	                       "FROM vettura " +
	                       "JOIN componente ON vettura.codice = componente.codice_vettura " +
	                       "JOIN iscrizione ON vettura.codice = iscrizione.codice_vettura " +
	                       "WHERE componente.tipo_motore = ? " +
	                       "GROUP BY vettura.codice, vettura.modello " +
	                       "ORDER BY totale_punti DESC";
	        preparedstatement = basedati.getConnection().prepareStatement(query);

	        // Imposta i parametri
	        preparedstatement.setString(1, tipomotoretxt.getText());

	        // Esegui la query
	        ResultSet rs = preparedstatement.executeQuery();

	        // Controlla se la query ha restituito almeno una riga
	        if (rs.next()) {
	            frame.setVisible(true);
	            do {
	                model.addRow(new Object[]{rs.getString("codice"), rs.getString("modello"), rs.getString("totale_punti")});
	            } while (rs.next());
	        } else {
	            fallimento14.main(null);
	            // Il componente non esiste per la vettura
	        }

	        // Chiudi il ResultSet e il PreparedStatement
	        rs.close();
	        preparedstatement.close();
	    } catch(SQLIntegrityConstraintViolationException e){
	        fallimento14.main(null);
	    } catch(Exception e) {
	    	fallimento4_1.main(null);
	        e.printStackTrace();
	    }
	}
}
