import javax.swing.*;
import java.awt.*;
import javax.swing.table.DefaultTableModel;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLIntegrityConstraintViolationException;

public class query15 extends JFrame {
    private static final long serialVersionUID = 1L;
    private Database basedati;

    public static void main(String[] args) {
        new query15();
    }
    
    public query15() {
        setLayout(new BorderLayout());

        // Crea un modello di tabella
        DefaultTableModel model = new DefaultTableModel(new String[]{"Codice Scuderia", "Nome Scuderia", "Rapporto Punti/Minuti"}, 0){
            private static final long serialVersionUID = 2L;
            @Override
            public boolean isCellEditable(int row, int column) {
                // Tutte le celle non sono modificabili
                return false;
            }
        };

        // Crea una tabella con il modello
        JTable table = new JTable(model);

        // Aggiungi la tabella a uno JScrollPane
        add(new JScrollPane(table), BorderLayout.CENTER);
        pack();
        setVisible(false);

        try {
            PreparedStatement preparedstatement;
            basedati = new Database(login.databaseName,login.databaseUsername,login.databasePassword);
            basedati.connect();

            // Seleziona le scuderie basate sul rapporto di punti ottenuti per minuti di gara
            String selectQuery = "SELECT scuderia.codice, scuderia.nome, SUM(iscrizione.punti) / (SUM(gara.durata) / 60.0) AS rapporto_punti_minuti " +
                                 "FROM scuderia " +
                                 "JOIN pilota ON scuderia.codice = pilota.codice_scuderia " +
                                 "JOIN iscrizione ON pilota.codice_vettura = iscrizione.codice_vettura " +
                                 "JOIN gara ON iscrizione.codice_gara = gara.codice " +
                                 "GROUP BY scuderia.codice, scuderia.nome " +
                                 "ORDER BY rapporto_punti_minuti DESC";
            preparedstatement = basedati.getConnection().prepareStatement(selectQuery);

            // Esegui la query
            ResultSet rs = preparedstatement.executeQuery();

            // Per ogni scuderia, aggiungi il codice, il nome e il rapporto punti/minuti alla tabella
            while (rs.next()) {
                String codiceScuderia = rs.getString("codice");
                String nomeScuderia = rs.getString("nome");
                double rapportoPuntiMinuti = rs.getDouble("rapporto_punti_minuti");

                // Aggiungi la riga alla tabella
                model.addRow(new Object[]{codiceScuderia, nomeScuderia, rapportoPuntiMinuti});
            }

            // Se la tabella ha almeno una riga, rendi visibile il frame
            if (model.getRowCount() > 0) {
                setVisible(true);
            } else {
                fallimento9.main(null);
            }

            // Chiudi il ResultSet e il PreparedStatement
            rs.close();
            preparedstatement.close();
        } catch(SQLIntegrityConstraintViolationException e){
            fallimento9.main(null);
        } catch(Exception e) {
        	fallimento4_1.main(null);
            e.printStackTrace();
        }
    }
}