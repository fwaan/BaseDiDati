import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.SWT;
import org.eclipse.jface.resource.LocalResourceManager;
import org.eclipse.jface.resource.JFaceResources;

import java.sql.*;

import org.eclipse.jface.resource.FontDescriptor;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.ModifyEvent;

public class query16_extra {

	private Database basedati;
	protected static Shell shell16;
	private LocalResourceManager localResourceManager;
	private final FormToolkit formToolkit = new FormToolkit(Display.getDefault());
	private Text nomecostruttoretxt;
	private Text sedecostruttoretxt;
	private Text ragionesocialetxt;

	public static void main(String[] args) {
		try {
			if(shell16 == null || shell16.isDisposed())
			{
				/**
				 * Launch the application.
				 * @param args
				 * @wbp.parser.entryPoint
				 */
				query16_extra window = new query16_extra();
				window.open();
			}
			else {
				shell16.forceActive();
				shell16.setMinimized(false);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 * @wbp.parser.entryPoint
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell16.open();
		shell16.layout();
		while (!shell16.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 * @wbp.parser.entryPoint
	 */
	protected void createContents() {
		shell16 = new Shell();
		createResourceManager();
		shell16.setImage(null);
		shell16.setSize(1258, 430);
		
		Label lblInserimentoCostruttore = new Label(shell16, SWT.NONE);
		lblInserimentoCostruttore.setAlignment(SWT.CENTER);
		lblInserimentoCostruttore.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 24, SWT.BOLD)));
		lblInserimentoCostruttore.setBounds(10, 10, 1222, 174);
		lblInserimentoCostruttore.setText("INSERISCI COSTRUTTORE");
		
		Label lblCodiceVettura = new Label(shell16, SWT.NONE);
		lblCodiceVettura.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 11, SWT.BOLD)));
		lblCodiceVettura.setBounds(10, 190, 280, 32);
		formToolkit.adapt(lblCodiceVettura, true, true);
		lblCodiceVettura.setText("NOME");
		
		Label lblSedeFabbrica = new Label(shell16, SWT.NONE);
		lblSedeFabbrica.setText("SEDE FABBRICA");
		lblSedeFabbrica.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 11, SWT.BOLD)));
		lblSedeFabbrica.setBounds(10, 228, 280, 32);
		formToolkit.adapt(lblSedeFabbrica, true, true);
		
		nomecostruttoretxt = new Text(shell16, SWT.BORDER);
		
		nomecostruttoretxt.setBounds(296, 191, 936, 32);
		formToolkit.adapt(nomecostruttoretxt, true, true);
		
		sedecostruttoretxt = new Text(shell16, SWT.BORDER);
		sedecostruttoretxt.setBounds(296, 229, 936, 32);
		formToolkit.adapt(sedecostruttoretxt, true, true);
		
		Button btnInserisciCostruttore = new Button(shell16, SWT.NONE);
		btnInserisciCostruttore.setEnabled(false);
		btnInserisciCostruttore.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				iscriviCostruttoreFunzione();
			}
		});
		btnInserisciCostruttore.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 26, SWT.BOLD)));
		btnInserisciCostruttore.setBounds(10, 304, 1222, 77);
		formToolkit.adapt(btnInserisciCostruttore, true, true);
		btnInserisciCostruttore.setText("INSERISCI");
		
		Label lblRagioneSociale = new Label(shell16, SWT.NONE);
		lblRagioneSociale.setText("RAGIONE SOCIALE");
		lblRagioneSociale.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 11, SWT.BOLD)));
		lblRagioneSociale.setBounds(10, 266, 280, 32);
		formToolkit.adapt(lblRagioneSociale, true, true);
		
		ragionesocialetxt = new Text(shell16, SWT.BORDER);
		ragionesocialetxt.setBounds(296, 266, 936, 32);
		formToolkit.adapt(ragionesocialetxt, true, true);
		
		nomecostruttoretxt.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				if(!nomecostruttoretxt.getText().isEmpty() && !sedecostruttoretxt.getText().isEmpty() && !ragionesocialetxt.getText().isEmpty()) btnInserisciCostruttore.setEnabled(true);
				if(nomecostruttoretxt.getText().isEmpty()) btnInserisciCostruttore.setEnabled(false);
			}
		});
		sedecostruttoretxt.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				if(!nomecostruttoretxt.getText().isEmpty() && !sedecostruttoretxt.getText().isEmpty() && !ragionesocialetxt.getText().isEmpty()) btnInserisciCostruttore.setEnabled(true);
				if(sedecostruttoretxt.getText().isEmpty()) btnInserisciCostruttore.setEnabled(false);
			}
		});
		ragionesocialetxt.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				if(!nomecostruttoretxt.getText().isEmpty() && !sedecostruttoretxt.getText().isEmpty() && !ragionesocialetxt.getText().isEmpty()) btnInserisciCostruttore.setEnabled(true);
				if(ragionesocialetxt.getText().isEmpty()) btnInserisciCostruttore.setEnabled(false);
			}
		});

	}
	/**
	 * @wbp.parser.entryPoint
	 */
	private void createResourceManager() {
		localResourceManager = new LocalResourceManager(JFaceResources.getResources(),shell16);
	}
	private void iscriviCostruttoreFunzione(){
	    try {
	        ResultSet rs;
	        PreparedStatement preparedstatement;
	        basedati = new Database(login.databaseName,login.databaseUsername,login.databasePassword);
	        basedati.connect();

	        // Controlla se esiste già un costruttore con lo stesso nome e sede_fabbrica
	        preparedstatement = basedati.getConnection().prepareStatement("SELECT COUNT(*) FROM basedidati.costruttore WHERE nome = ? AND sede_fabbrica = ?");
	        preparedstatement.setString(1, nomecostruttoretxt.getText());
	        preparedstatement.setString(2, sedecostruttoretxt.getText());
	        rs = preparedstatement.executeQuery();
	        rs.next();
	        boolean existsConstructor = rs.getInt(1) > 0;
	        rs.close();
	        preparedstatement.close();

	        // Se esiste già un costruttore con lo stesso nome e sede_fabbrica, non inserire il nuovo costruttore
	        if(existsConstructor) {
	            fallimento16.main(null);
	        } else {
	            // Inserisci il nuovo costruttore
	            preparedstatement = basedati.getConnection().prepareStatement("INSERT INTO basedidati.costruttore (nome, sede_fabbrica, ragione_sociale, componenti) VALUES (?, ?, ?, '0')");
	            preparedstatement.setString(1, nomecostruttoretxt.getText());
		        preparedstatement.setString(2, sedecostruttoretxt.getText());
		        preparedstatement.setString(3, ragionesocialetxt.getText());
	            int controlloquery1 = preparedstatement.executeUpdate();

	            if(controlloquery1>0) {
	                successo.main(null);
	            }
	        }

	        basedati.close();
	    } catch(SQLIntegrityConstraintViolationException e){
	        fallimento16.main(null);
	    } catch(Exception e) {
	    	fallimento4_1.main(null);
	        e.printStackTrace();
	    }
	}
}
