import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.SWT;
import org.eclipse.jface.resource.LocalResourceManager;
import org.eclipse.jface.resource.JFaceResources;

import java.sql.*;

import org.eclipse.jface.resource.FontDescriptor;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.DateTime;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.ModifyEvent;

public class query2 {

	private Database basedati;
	protected static Shell shell2;
	private LocalResourceManager localResourceManager2;
	private final FormToolkit formToolkit = new FormToolkit(Display.getDefault());
	private Text codicevetturatxt;
	private Text modellovetturatxt;
	private Text codicemotoretxt;
	private Text codicecambiotxt;
	private Text codicetelaiotxt;
	private Text costomotoretxt;
	private Text tipomotoretxt;
	private Text cilindritxt;
	private Text cilindratatxt;
	private Text nomecostruttoremotoretxt;
	private Text sedefabbricamotoretxt;
	private Text sedefabbricacambiotxt;
	private Text costocambiotxt;
	private Text marcetxt;
	private Text nomecostruttorecambiotxt;
	private Text costotelaiotxt;
	private Text materialetxt;
	private Text pesotxt;
	private Text nomecostruttoretelaiotxt;
	private Text sedefabbricatelaiotxt;
	private String DataAnno1 = "";
	private String DataMese1 = "";
	private String DataGiorno1 = "";
	private String DataAnno2 = "";
	private String DataMese2 = "";
	private String DataGiorno2 = "";
	private String DataAnno3 = "";
	private String DataMese3 = "";
	private String DataGiorno3 = "";
	private Label lblMotoreCodice;


	public static void main(String[] args) {
		try {
			if(shell2 == null || shell2.isDisposed())
			{
				/**
				 * Launch the application.
				 * @param args
				 */
				query2 window = new query2();
				window.open();
			}
			else {
				shell2.forceActive();
				shell2.setMinimized(false);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell2.open();
		shell2.layout();
		while (!shell2.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 * @wbp.parser.entryPoint
	 */
	protected void createContents() {
		shell2 = new Shell();
		createResourceManager();
		shell2.setImage(null);
		shell2.setSize(1432, 912);
		
		Label lblnserimentoVettura = new Label(shell2, SWT.NONE);
		lblnserimentoVettura.setAlignment(SWT.CENTER);
		lblnserimentoVettura.setFont(localResourceManager2.create(FontDescriptor.createFrom("Segoe UI", 24, SWT.BOLD)));
		lblnserimentoVettura.setBounds(10, 11, 1397, 74);
		lblnserimentoVettura.setText("INSERIMENTO VETTURA");
		
		Label lblCodiceVettura = new Label(shell2, SWT.NONE);
		lblCodiceVettura.setFont(localResourceManager2.create(FontDescriptor.createFrom("Segoe UI", 11, SWT.BOLD)));
		lblCodiceVettura.setBounds(10, 91, 258, 32);
		formToolkit.adapt(lblCodiceVettura, true, true);
		lblCodiceVettura.setText("CODICE VETTURA");
		
		Label lblModelloVettura = new Label(shell2, SWT.NONE);
		lblModelloVettura.setText("MODELLO VETTURA");
		lblModelloVettura.setFont(localResourceManager2.create(FontDescriptor.createFrom("Segoe UI", 11, SWT.BOLD)));
		lblModelloVettura.setBounds(10, 143, 258, 32);
		formToolkit.adapt(lblModelloVettura, true, true);
		
		codicevetturatxt = new Text(shell2, SWT.BORDER);
		
		codicevetturatxt.setBounds(274, 91, 1135, 32);
		formToolkit.adapt(codicevetturatxt, true, true);
		
		modellovetturatxt = new Text(shell2, SWT.BORDER);
		modellovetturatxt.setBounds(274, 143, 1135, 32);
		formToolkit.adapt(modellovetturatxt, true, true);
		
		lblMotoreCodice = new Label(shell2, SWT.NONE);
		lblMotoreCodice.setText("- MOTORE [CODICE]");
		lblMotoreCodice.setFont(localResourceManager2.create(FontDescriptor.createFrom("Segoe UI", 11, SWT.BOLD)));
		lblMotoreCodice.setBounds(10, 211, 258, 32);
		formToolkit.adapt(lblMotoreCodice, true, true);
		
		Label lblCambio = new Label(shell2, SWT.NONE);
		lblCambio.setText("- CAMBIO [CODICE]");
		lblCambio.setFont(localResourceManager2.create(FontDescriptor.createFrom("Segoe UI", 11, SWT.BOLD)));
		lblCambio.setBounds(730, 205, 233, 32);
		formToolkit.adapt(lblCambio, true, true);
		
		Label lblTelaio = new Label(shell2, SWT.NONE);
		lblTelaio.setText("- TELAIO [CODICE]");
		lblTelaio.setFont(localResourceManager2.create(FontDescriptor.createFrom("Segoe UI", 11, SWT.BOLD)));
		lblTelaio.setBounds(10, 515, 258, 32);
		formToolkit.adapt(lblTelaio, true, true);
		
		codicemotoretxt = new Text(shell2, SWT.BORDER);
		codicemotoretxt.setBounds(274, 206, 450, 32);
		formToolkit.adapt(codicemotoretxt, true, true);
		
		codicecambiotxt = new Text(shell2, SWT.BORDER);
		codicecambiotxt.setBounds(969, 205, 440, 32);
		formToolkit.adapt(codicecambiotxt, true, true);
		
		codicetelaiotxt = new Text(shell2, SWT.BORDER);
		codicetelaiotxt.setBounds(274, 510, 450, 32);
		formToolkit.adapt(codicetelaiotxt, true, true);
		
		Label lblDataInstallazioneMotore = new Label(shell2, SWT.NONE);
		lblDataInstallazioneMotore.setText("||DATA INSTALLAZIONE");
		lblDataInstallazioneMotore.setFont(localResourceManager2.create(FontDescriptor.createFrom("Segoe UI", 10, SWT.BOLD)));
		lblDataInstallazioneMotore.setBounds(10, 249, 258, 32);
		formToolkit.adapt(lblDataInstallazioneMotore, true, true);
		
		Label lblCostoMotore = new Label(shell2, SWT.NONE);
		lblCostoMotore.setText("||COSTO");
		lblCostoMotore.setFont(localResourceManager2.create(FontDescriptor.createFrom("Segoe UI", 10, SWT.BOLD)));
		lblCostoMotore.setBounds(10, 287, 258, 32);
		formToolkit.adapt(lblCostoMotore, true, true);
		
		costomotoretxt = new Text(shell2, SWT.BORDER);
		costomotoretxt.setBounds(274, 282, 450, 32);
		formToolkit.adapt(costomotoretxt, true, true);
		
		Label lblTipo = new Label(shell2, SWT.NONE);
		lblTipo.setText("||TIPO");
		lblTipo.setFont(localResourceManager2.create(FontDescriptor.createFrom("Segoe UI", 10, SWT.BOLD)));
		lblTipo.setBounds(10, 325, 258, 32);
		formToolkit.adapt(lblTipo, true, true);
		
		tipomotoretxt = new Text(shell2, SWT.BORDER);
		tipomotoretxt.setBounds(274, 320, 450, 32);
		formToolkit.adapt(tipomotoretxt, true, true);
		
		Label lblCilindri = new Label(shell2, SWT.NONE);
		lblCilindri.setText("||CILINDRI");
		lblCilindri.setFont(localResourceManager2.create(FontDescriptor.createFrom("Segoe UI", 10, SWT.BOLD)));
		lblCilindri.setBounds(10, 363, 258, 32);
		formToolkit.adapt(lblCilindri, true, true);
		
		Label lblCilindrata = new Label(shell2, SWT.NONE);
		lblCilindrata.setText("||CILINDRATA");
		lblCilindrata.setFont(localResourceManager2.create(FontDescriptor.createFrom("Segoe UI", 10, SWT.BOLD)));
		lblCilindrata.setBounds(10, 401, 258, 32);
		formToolkit.adapt(lblCilindrata, true, true);
		
		Label lblNomeCostruttore = new Label(shell2, SWT.NONE);
		lblNomeCostruttore.setText("||NOME COSTRUTTORE");
		lblNomeCostruttore.setFont(localResourceManager2.create(FontDescriptor.createFrom("Segoe UI", 10, SWT.BOLD)));
		lblNomeCostruttore.setBounds(10, 439, 258, 32);
		formToolkit.adapt(lblNomeCostruttore, true, true);
		
		Label lblSedeFabbrica = new Label(shell2, SWT.NONE);
		lblSedeFabbrica.setText("||SEDE FABBRICA");
		lblSedeFabbrica.setFont(localResourceManager2.create(FontDescriptor.createFrom("Segoe UI", 10, SWT.BOLD)));
		lblSedeFabbrica.setBounds(10, 477, 258, 32);
		formToolkit.adapt(lblSedeFabbrica, true, true);
		
		cilindritxt = new Text(shell2, SWT.BORDER);
		cilindritxt.setBounds(274, 358, 450, 32);
		formToolkit.adapt(cilindritxt, true, true);
		
		cilindratatxt = new Text(shell2, SWT.BORDER);
		cilindratatxt.setBounds(274, 396, 450, 32);
		formToolkit.adapt(cilindratatxt, true, true);
		
		nomecostruttoremotoretxt = new Text(shell2, SWT.BORDER);
		nomecostruttoremotoretxt.setBounds(274, 434, 450, 32);
		formToolkit.adapt(nomecostruttoremotoretxt, true, true);
		
		sedefabbricamotoretxt = new Text(shell2, SWT.BORDER);
		sedefabbricamotoretxt.setBounds(274, 472, 450, 32);
		formToolkit.adapt(sedefabbricamotoretxt, true, true);
		
		Label lblDataInstallazioneCambio = new Label(shell2, SWT.NONE);
		lblDataInstallazioneCambio.setText("||DATA INSTALLAZIONE");
		lblDataInstallazioneCambio.setFont(localResourceManager2.create(FontDescriptor.createFrom("Segoe UI", 10, SWT.BOLD)));
		lblDataInstallazioneCambio.setBounds(730, 243, 233, 32);
		formToolkit.adapt(lblDataInstallazioneCambio, true, true);
		
		Label lblCostoCambio = new Label(shell2, SWT.NONE);
		lblCostoCambio.setText("||COSTO");
		lblCostoCambio.setFont(localResourceManager2.create(FontDescriptor.createFrom("Segoe UI", 10, SWT.BOLD)));
		lblCostoCambio.setBounds(730, 282, 233, 32);
		formToolkit.adapt(lblCostoCambio, true, true);
		
		Label lblMarce = new Label(shell2, SWT.NONE);
		lblMarce.setText("||MARCE");
		lblMarce.setFont(localResourceManager2.create(FontDescriptor.createFrom("Segoe UI", 10, SWT.BOLD)));
		lblMarce.setBounds(730, 321, 233, 32);
		formToolkit.adapt(lblMarce, true, true);
		
		Label lblNomeCostruttoreCambio = new Label(shell2, SWT.NONE);
		lblNomeCostruttoreCambio.setText("||NOME COSTRUTTORE");
		lblNomeCostruttoreCambio.setFont(localResourceManager2.create(FontDescriptor.createFrom("Segoe UI", 10, SWT.BOLD)));
		lblNomeCostruttoreCambio.setBounds(730, 358, 233, 32);
		formToolkit.adapt(lblNomeCostruttoreCambio, true, true);
		
		Label lblSedeFabbricaCambio = new Label(shell2, SWT.NONE);
		lblSedeFabbricaCambio.setText("||SEDE FABBRICA");
		lblSedeFabbricaCambio.setFont(localResourceManager2.create(FontDescriptor.createFrom("Segoe UI", 10, SWT.BOLD)));
		lblSedeFabbricaCambio.setBounds(730, 397, 233, 32);
		formToolkit.adapt(lblSedeFabbricaCambio, true, true);
		
		costocambiotxt = new Text(shell2, SWT.BORDER);
		costocambiotxt.setBounds(969, 281, 440, 32);
		formToolkit.adapt(costocambiotxt, true, true);
		
		marcetxt = new Text(shell2, SWT.BORDER);
		marcetxt.setBounds(969, 320, 440, 32);
		formToolkit.adapt(marcetxt, true, true);
		
		nomecostruttorecambiotxt = new Text(shell2, SWT.BORDER);
		nomecostruttorecambiotxt.setBounds(969, 358, 440, 32);
		formToolkit.adapt(nomecostruttorecambiotxt, true, true);
		
		sedefabbricacambiotxt = new Text(shell2, SWT.BORDER);
		sedefabbricacambiotxt.setBounds(969, 396, 440, 32);
		formToolkit.adapt(sedefabbricacambiotxt, true, true);
		
		Label lblDataInstallazioneTelaio = new Label(shell2, SWT.NONE);
		lblDataInstallazioneTelaio.setText("||DATA INSTALLAZIONE");
		lblDataInstallazioneTelaio.setFont(localResourceManager2.create(FontDescriptor.createFrom("Segoe UI", 10, SWT.BOLD)));
		lblDataInstallazioneTelaio.setBounds(10, 553, 258, 32);
		formToolkit.adapt(lblDataInstallazioneTelaio, true, true);
		
		Label lblCostoTelaio = new Label(shell2, SWT.NONE);
		lblCostoTelaio.setText("||COSTO");
		lblCostoTelaio.setFont(localResourceManager2.create(FontDescriptor.createFrom("Segoe UI", 10, SWT.BOLD)));
		lblCostoTelaio.setBounds(10, 591, 258, 32);
		formToolkit.adapt(lblCostoTelaio, true, true);
		
		costotelaiotxt = new Text(shell2, SWT.BORDER);
		costotelaiotxt.setBounds(274, 590, 450, 32);
		formToolkit.adapt(costotelaiotxt, true, true);
		
		Label lblMateriale = new Label(shell2, SWT.NONE);
		lblMateriale.setText("||MATERIALE");
		lblMateriale.setFont(localResourceManager2.create(FontDescriptor.createFrom("Segoe UI", 10, SWT.BOLD)));
		lblMateriale.setBounds(10, 629, 258, 32);
		formToolkit.adapt(lblMateriale, true, true);
		
		Label lblPeso = new Label(shell2, SWT.NONE);
		lblPeso.setText("||PESO");
		lblPeso.setFont(localResourceManager2.create(FontDescriptor.createFrom("Segoe UI", 10, SWT.BOLD)));
		lblPeso.setBounds(10, 667, 258, 32);
		formToolkit.adapt(lblPeso, true, true);
		
		materialetxt = new Text(shell2, SWT.BORDER);
		materialetxt.setBounds(274, 628, 450, 32);
		formToolkit.adapt(materialetxt, true, true);
		
		pesotxt = new Text(shell2, SWT.BORDER);
		pesotxt.setBounds(274, 666, 450, 32);
		formToolkit.adapt(pesotxt, true, true);
		
		Label lblNomeCostruttoreTelaio = new Label(shell2, SWT.NONE);
		lblNomeCostruttoreTelaio.setText("||NOME COSTRUTTORE");
		lblNomeCostruttoreTelaio.setFont(localResourceManager2.create(FontDescriptor.createFrom("Segoe UI", 10, SWT.BOLD)));
		lblNomeCostruttoreTelaio.setBounds(10, 705, 258, 32);
		formToolkit.adapt(lblNomeCostruttoreTelaio, true, true);
		
		Label lblSedeFabbricaTelaio = new Label(shell2, SWT.NONE);
		lblSedeFabbricaTelaio.setText("||SEDE FABBRICA");
		lblSedeFabbricaTelaio.setFont(localResourceManager2.create(FontDescriptor.createFrom("Segoe UI", 10, SWT.BOLD)));
		lblSedeFabbricaTelaio.setBounds(10, 743, 258, 32);
		formToolkit.adapt(lblSedeFabbricaTelaio, true, true);
		
		nomecostruttoretelaiotxt = new Text(shell2, SWT.BORDER);
		nomecostruttoretelaiotxt.setBounds(274, 704, 450, 32);
		formToolkit.adapt(nomecostruttoretelaiotxt, true, true);
		
		sedefabbricatelaiotxt = new Text(shell2, SWT.BORDER);
		sedefabbricatelaiotxt.setBounds(274, 742, 450, 32);
		formToolkit.adapt(sedefabbricatelaiotxt, true, true);
		
		DateTime datainstallazionemotore = new DateTime(shell2, SWT.BORDER);
		datainstallazionemotore.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				DataAnno1 = Integer.toString(datainstallazionemotore.getYear());
				DataMese1 = Integer.toString(datainstallazionemotore.getMonth() + 1);
				DataGiorno1 = Integer.toString(datainstallazionemotore.getDay());
			}
		});
		datainstallazionemotore.setBounds(274, 244, 450, 32);
		formToolkit.adapt(datainstallazionemotore);
		formToolkit.paintBordersFor(datainstallazionemotore);
		
		DateTime datainstallazionecambio = new DateTime(shell2, SWT.BORDER);
		datainstallazionecambio.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				DataAnno2 = Integer.toString(datainstallazionecambio.getYear());
				DataMese2 = Integer.toString(datainstallazionecambio.getMonth() + 1);
				DataGiorno2 = Integer.toString(datainstallazionecambio.getDay());
			}
		});
		datainstallazionecambio.setBounds(969, 243, 440, 32);
		formToolkit.adapt(datainstallazionecambio);
		formToolkit.paintBordersFor(datainstallazionecambio);
		
		DateTime datainstallazionetelaio = new DateTime(shell2, SWT.BORDER);
		datainstallazionetelaio.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				DataAnno3 = Integer.toString(datainstallazionetelaio.getYear());
				DataMese3 = Integer.toString(datainstallazionetelaio.getMonth() + 1);
				DataGiorno3 = Integer.toString(datainstallazionetelaio.getDay());
			}
		});
		datainstallazionetelaio.setBounds(274, 553, 450, 32);
		formToolkit.adapt(datainstallazionetelaio);
		formToolkit.paintBordersFor(datainstallazionetelaio);
		
		Button btnInserisciVettura = new Button(shell2, SWT.NONE);
		btnInserisciVettura.setEnabled(false);
		btnInserisciVettura.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				registraVetturaBottoneFunzione();
			}
		});
		btnInserisciVettura.setFont(localResourceManager2.create(FontDescriptor.createFrom("Segoe UI", 26, SWT.BOLD)));
		btnInserisciVettura.setBounds(10, 781, 1397, 82);
		formToolkit.adapt(btnInserisciVettura, true, true);
		btnInserisciVettura.setText("INSERISCI");
		codicevetturatxt.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				if(!codicevetturatxt.getText().isEmpty() && !codicemotoretxt.getText().isEmpty() && !costomotoretxt.getText().isEmpty() && !tipomotoretxt.getText().isEmpty() && !cilindritxt.getText().isEmpty() && !cilindratatxt.getText().isEmpty() && !nomecostruttoremotoretxt.getText().isEmpty() && !sedefabbricamotoretxt.getText().isEmpty() && !codicecambiotxt.getText().isEmpty() && !costocambiotxt.getText().isEmpty() && !marcetxt.getText().isEmpty() && !nomecostruttorecambiotxt.getText().isEmpty() && !sedefabbricacambiotxt.getText().isEmpty() && !codicetelaiotxt.getText().isEmpty() && !costotelaiotxt.getText().isEmpty() && !materialetxt.getText().isEmpty() && !pesotxt.getText().isEmpty() && !nomecostruttoretelaiotxt.getText().isEmpty() && !sedefabbricatelaiotxt.getText().isEmpty() && !DataAnno1.isEmpty() && !DataMese1.isEmpty() && !DataGiorno1.isEmpty() && !DataAnno2.isEmpty() && !DataMese2.isEmpty() && !DataGiorno2.isEmpty() && !DataAnno3.isEmpty() && !DataMese3.isEmpty() && !DataGiorno3.isEmpty()) btnInserisciVettura.setEnabled(true);
				if(codicevetturatxt.getText().isEmpty()) btnInserisciVettura.setEnabled(false);
			}
		});
		modellovetturatxt.addModifyListener(new ModifyListener() {
		    public void modifyText(ModifyEvent e) {
		    	if(!codicevetturatxt.getText().isEmpty() && !codicemotoretxt.getText().isEmpty() && !costomotoretxt.getText().isEmpty() && !tipomotoretxt.getText().isEmpty() && !cilindritxt.getText().isEmpty() && !cilindratatxt.getText().isEmpty() && !nomecostruttoremotoretxt.getText().isEmpty() && !sedefabbricamotoretxt.getText().isEmpty() && !codicecambiotxt.getText().isEmpty() && !costocambiotxt.getText().isEmpty() && !marcetxt.getText().isEmpty() && !nomecostruttorecambiotxt.getText().isEmpty() && !sedefabbricacambiotxt.getText().isEmpty() && !codicetelaiotxt.getText().isEmpty() && !costotelaiotxt.getText().isEmpty() && !materialetxt.getText().isEmpty() && !pesotxt.getText().isEmpty() && !nomecostruttoretelaiotxt.getText().isEmpty() && !sedefabbricatelaiotxt.getText().isEmpty() && !DataAnno1.isEmpty() && !DataMese1.isEmpty() && !DataGiorno1.isEmpty() && !DataAnno2.isEmpty() && !DataMese2.isEmpty() && !DataGiorno2.isEmpty() && !DataAnno3.isEmpty() && !DataMese3.isEmpty() && !DataGiorno3.isEmpty()) btnInserisciVettura.setEnabled(true);
		        if(modellovetturatxt.getText().isEmpty()) btnInserisciVettura.setEnabled(false);
		    }
		});

		codicemotoretxt.addModifyListener(new ModifyListener() {
		    public void modifyText(ModifyEvent e) {
		    	if(!codicevetturatxt.getText().isEmpty() && !codicemotoretxt.getText().isEmpty() && !costomotoretxt.getText().isEmpty() && !tipomotoretxt.getText().isEmpty() && !cilindritxt.getText().isEmpty() && !cilindratatxt.getText().isEmpty() && !nomecostruttoremotoretxt.getText().isEmpty() && !sedefabbricamotoretxt.getText().isEmpty() && !codicecambiotxt.getText().isEmpty() && !costocambiotxt.getText().isEmpty() && !marcetxt.getText().isEmpty() && !nomecostruttorecambiotxt.getText().isEmpty() && !sedefabbricacambiotxt.getText().isEmpty() && !codicetelaiotxt.getText().isEmpty() && !costotelaiotxt.getText().isEmpty() && !materialetxt.getText().isEmpty() && !pesotxt.getText().isEmpty() && !nomecostruttoretelaiotxt.getText().isEmpty() && !sedefabbricatelaiotxt.getText().isEmpty() && !DataAnno1.isEmpty() && !DataMese1.isEmpty() && !DataGiorno1.isEmpty() && !DataAnno2.isEmpty() && !DataMese2.isEmpty() && !DataGiorno2.isEmpty() && !DataAnno3.isEmpty() && !DataMese3.isEmpty() && !DataGiorno3.isEmpty()) btnInserisciVettura.setEnabled(true);
		        if(codicemotoretxt.getText().isEmpty()) btnInserisciVettura.setEnabled(false);
		    }
		});

		tipomotoretxt.addModifyListener(new ModifyListener() {
		    public void modifyText(ModifyEvent e) {
		    	if(!codicevetturatxt.getText().isEmpty() && !codicemotoretxt.getText().isEmpty() && !costomotoretxt.getText().isEmpty() && !tipomotoretxt.getText().isEmpty() && !cilindritxt.getText().isEmpty() && !cilindratatxt.getText().isEmpty() && !nomecostruttoremotoretxt.getText().isEmpty() && !sedefabbricamotoretxt.getText().isEmpty() && !codicecambiotxt.getText().isEmpty() && !costocambiotxt.getText().isEmpty() && !marcetxt.getText().isEmpty() && !nomecostruttorecambiotxt.getText().isEmpty() && !sedefabbricacambiotxt.getText().isEmpty() && !codicetelaiotxt.getText().isEmpty() && !costotelaiotxt.getText().isEmpty() && !materialetxt.getText().isEmpty() && !pesotxt.getText().isEmpty() && !nomecostruttoretelaiotxt.getText().isEmpty() && !sedefabbricatelaiotxt.getText().isEmpty() && !DataAnno1.isEmpty() && !DataMese1.isEmpty() && !DataGiorno1.isEmpty() && !DataAnno2.isEmpty() && !DataMese2.isEmpty() && !DataGiorno2.isEmpty() && !DataAnno3.isEmpty() && !DataMese3.isEmpty() && !DataGiorno3.isEmpty()) btnInserisciVettura.setEnabled(true);
		        if(tipomotoretxt.getText().isEmpty()) btnInserisciVettura.setEnabled(false);
		    }
		});

		cilindritxt.addModifyListener(new ModifyListener() {
		    public void modifyText(ModifyEvent e) {
		    	if(!codicevetturatxt.getText().isEmpty() && !codicemotoretxt.getText().isEmpty() && !costomotoretxt.getText().isEmpty() && !tipomotoretxt.getText().isEmpty() && !cilindritxt.getText().isEmpty() && !cilindratatxt.getText().isEmpty() && !nomecostruttoremotoretxt.getText().isEmpty() && !sedefabbricamotoretxt.getText().isEmpty() && !codicecambiotxt.getText().isEmpty() && !costocambiotxt.getText().isEmpty() && !marcetxt.getText().isEmpty() && !nomecostruttorecambiotxt.getText().isEmpty() && !sedefabbricacambiotxt.getText().isEmpty() && !codicetelaiotxt.getText().isEmpty() && !costotelaiotxt.getText().isEmpty() && !materialetxt.getText().isEmpty() && !pesotxt.getText().isEmpty() && !nomecostruttoretelaiotxt.getText().isEmpty() && !sedefabbricatelaiotxt.getText().isEmpty() && !DataAnno1.isEmpty() && !DataMese1.isEmpty() && !DataGiorno1.isEmpty() && !DataAnno2.isEmpty() && !DataMese2.isEmpty() && !DataGiorno2.isEmpty() && !DataAnno3.isEmpty() && !DataMese3.isEmpty() && !DataGiorno3.isEmpty()) btnInserisciVettura.setEnabled(true);
		        if(cilindritxt.getText().isEmpty()) btnInserisciVettura.setEnabled(false);
		    }
		});

		cilindratatxt.addModifyListener(new ModifyListener() {
		    public void modifyText(ModifyEvent e) {
		    	if(!codicevetturatxt.getText().isEmpty() && !codicemotoretxt.getText().isEmpty() && !costomotoretxt.getText().isEmpty() && !tipomotoretxt.getText().isEmpty() && !cilindritxt.getText().isEmpty() && !cilindratatxt.getText().isEmpty() && !nomecostruttoremotoretxt.getText().isEmpty() && !sedefabbricamotoretxt.getText().isEmpty() && !codicecambiotxt.getText().isEmpty() && !costocambiotxt.getText().isEmpty() && !marcetxt.getText().isEmpty() && !nomecostruttorecambiotxt.getText().isEmpty() && !sedefabbricacambiotxt.getText().isEmpty() && !codicetelaiotxt.getText().isEmpty() && !costotelaiotxt.getText().isEmpty() && !materialetxt.getText().isEmpty() && !pesotxt.getText().isEmpty() && !nomecostruttoretelaiotxt.getText().isEmpty() && !sedefabbricatelaiotxt.getText().isEmpty() && !DataAnno1.isEmpty() && !DataMese1.isEmpty() && !DataGiorno1.isEmpty() && !DataAnno2.isEmpty() && !DataMese2.isEmpty() && !DataGiorno2.isEmpty() && !DataAnno3.isEmpty() && !DataMese3.isEmpty() && !DataGiorno3.isEmpty()) btnInserisciVettura.setEnabled(true);
		        if(cilindratatxt.getText().isEmpty()) btnInserisciVettura.setEnabled(false);
		    }
		});

		nomecostruttoremotoretxt.addModifyListener(new ModifyListener() {
		    public void modifyText(ModifyEvent e) {
		    	if(!codicevetturatxt.getText().isEmpty() && !codicemotoretxt.getText().isEmpty() && !costomotoretxt.getText().isEmpty() && !tipomotoretxt.getText().isEmpty() && !cilindritxt.getText().isEmpty() && !cilindratatxt.getText().isEmpty() && !nomecostruttoremotoretxt.getText().isEmpty() && !sedefabbricamotoretxt.getText().isEmpty() && !codicecambiotxt.getText().isEmpty() && !costocambiotxt.getText().isEmpty() && !marcetxt.getText().isEmpty() && !nomecostruttorecambiotxt.getText().isEmpty() && !sedefabbricacambiotxt.getText().isEmpty() && !codicetelaiotxt.getText().isEmpty() && !costotelaiotxt.getText().isEmpty() && !materialetxt.getText().isEmpty() && !pesotxt.getText().isEmpty() && !nomecostruttoretelaiotxt.getText().isEmpty() && !sedefabbricatelaiotxt.getText().isEmpty() && !DataAnno1.isEmpty() && !DataMese1.isEmpty() && !DataGiorno1.isEmpty() && !DataAnno2.isEmpty() && !DataMese2.isEmpty() && !DataGiorno2.isEmpty() && !DataAnno3.isEmpty() && !DataMese3.isEmpty() && !DataGiorno3.isEmpty()) btnInserisciVettura.setEnabled(true);
		        if(nomecostruttoremotoretxt.getText().isEmpty()) btnInserisciVettura.setEnabled(false);
		    }
		});

		sedefabbricamotoretxt.addModifyListener(new ModifyListener() {
		    public void modifyText(ModifyEvent e) {
		    	if(!codicevetturatxt.getText().isEmpty() && !codicemotoretxt.getText().isEmpty() && !costomotoretxt.getText().isEmpty() && !tipomotoretxt.getText().isEmpty() && !cilindritxt.getText().isEmpty() && !cilindratatxt.getText().isEmpty() && !nomecostruttoremotoretxt.getText().isEmpty() && !sedefabbricamotoretxt.getText().isEmpty() && !codicecambiotxt.getText().isEmpty() && !costocambiotxt.getText().isEmpty() && !marcetxt.getText().isEmpty() && !nomecostruttorecambiotxt.getText().isEmpty() && !sedefabbricacambiotxt.getText().isEmpty() && !codicetelaiotxt.getText().isEmpty() && !costotelaiotxt.getText().isEmpty() && !materialetxt.getText().isEmpty() && !pesotxt.getText().isEmpty() && !nomecostruttoretelaiotxt.getText().isEmpty() && !sedefabbricatelaiotxt.getText().isEmpty() && !DataAnno1.isEmpty() && !DataMese1.isEmpty() && !DataGiorno1.isEmpty() && !DataAnno2.isEmpty() && !DataMese2.isEmpty() && !DataGiorno2.isEmpty() && !DataAnno3.isEmpty() && !DataMese3.isEmpty() && !DataGiorno3.isEmpty()) btnInserisciVettura.setEnabled(true);
		        if(sedefabbricamotoretxt.getText().isEmpty()) btnInserisciVettura.setEnabled(false);
		    }
		});

		codicecambiotxt.addModifyListener(new ModifyListener() {
		    public void modifyText(ModifyEvent e) {
		    	if(!codicevetturatxt.getText().isEmpty() && !codicemotoretxt.getText().isEmpty() && !costomotoretxt.getText().isEmpty() && !tipomotoretxt.getText().isEmpty() && !cilindritxt.getText().isEmpty() && !cilindratatxt.getText().isEmpty() && !nomecostruttoremotoretxt.getText().isEmpty() && !sedefabbricamotoretxt.getText().isEmpty() && !codicecambiotxt.getText().isEmpty() && !costocambiotxt.getText().isEmpty() && !marcetxt.getText().isEmpty() && !nomecostruttorecambiotxt.getText().isEmpty() && !sedefabbricacambiotxt.getText().isEmpty() && !codicetelaiotxt.getText().isEmpty() && !costotelaiotxt.getText().isEmpty() && !materialetxt.getText().isEmpty() && !pesotxt.getText().isEmpty() && !nomecostruttoretelaiotxt.getText().isEmpty() && !sedefabbricatelaiotxt.getText().isEmpty() && !DataAnno1.isEmpty() && !DataMese1.isEmpty() && !DataGiorno1.isEmpty() && !DataAnno2.isEmpty() && !DataMese2.isEmpty() && !DataGiorno2.isEmpty() && !DataAnno3.isEmpty() && !DataMese3.isEmpty() && !DataGiorno3.isEmpty()) btnInserisciVettura.setEnabled(true);
		        if(codicecambiotxt.getText().isEmpty()) btnInserisciVettura.setEnabled(false);
		    }
		});

		costocambiotxt.addModifyListener(new ModifyListener() {
		    public void modifyText(ModifyEvent e) {
		    	if(!codicevetturatxt.getText().isEmpty() && !codicemotoretxt.getText().isEmpty() && !costomotoretxt.getText().isEmpty() && !tipomotoretxt.getText().isEmpty() && !cilindritxt.getText().isEmpty() && !cilindratatxt.getText().isEmpty() && !nomecostruttoremotoretxt.getText().isEmpty() && !sedefabbricamotoretxt.getText().isEmpty() && !codicecambiotxt.getText().isEmpty() && !costocambiotxt.getText().isEmpty() && !marcetxt.getText().isEmpty() && !nomecostruttorecambiotxt.getText().isEmpty() && !sedefabbricacambiotxt.getText().isEmpty() && !codicetelaiotxt.getText().isEmpty() && !costotelaiotxt.getText().isEmpty() && !materialetxt.getText().isEmpty() && !pesotxt.getText().isEmpty() && !nomecostruttoretelaiotxt.getText().isEmpty() && !sedefabbricatelaiotxt.getText().isEmpty() && !DataAnno1.isEmpty() && !DataMese1.isEmpty() && !DataGiorno1.isEmpty() && !DataAnno2.isEmpty() && !DataMese2.isEmpty() && !DataGiorno2.isEmpty() && !DataAnno3.isEmpty() && !DataMese3.isEmpty() && !DataGiorno3.isEmpty()) btnInserisciVettura.setEnabled(true);
		        if(costocambiotxt.getText().isEmpty()) btnInserisciVettura.setEnabled(false);
		    }
		});

		marcetxt.addModifyListener(new ModifyListener() {
		    public void modifyText(ModifyEvent e) {
		    	if(!codicevetturatxt.getText().isEmpty() && !codicemotoretxt.getText().isEmpty() && !costomotoretxt.getText().isEmpty() && !tipomotoretxt.getText().isEmpty() && !cilindritxt.getText().isEmpty() && !cilindratatxt.getText().isEmpty() && !nomecostruttoremotoretxt.getText().isEmpty() && !sedefabbricamotoretxt.getText().isEmpty() && !codicecambiotxt.getText().isEmpty() && !costocambiotxt.getText().isEmpty() && !marcetxt.getText().isEmpty() && !nomecostruttorecambiotxt.getText().isEmpty() && !sedefabbricacambiotxt.getText().isEmpty() && !codicetelaiotxt.getText().isEmpty() && !costotelaiotxt.getText().isEmpty() && !materialetxt.getText().isEmpty() && !pesotxt.getText().isEmpty() && !nomecostruttoretelaiotxt.getText().isEmpty() && !sedefabbricatelaiotxt.getText().isEmpty() && !DataAnno1.isEmpty() && !DataMese1.isEmpty() && !DataGiorno1.isEmpty() && !DataAnno2.isEmpty() && !DataMese2.isEmpty() && !DataGiorno2.isEmpty() && !DataAnno3.isEmpty() && !DataMese3.isEmpty() && !DataGiorno3.isEmpty()) btnInserisciVettura.setEnabled(true);
		        if(marcetxt.getText().isEmpty()) btnInserisciVettura.setEnabled(false);
		    }
		});

		nomecostruttorecambiotxt.addModifyListener(new ModifyListener() {
		    public void modifyText(ModifyEvent e) {
		    	if(!codicevetturatxt.getText().isEmpty() && !codicemotoretxt.getText().isEmpty() && !costomotoretxt.getText().isEmpty() && !tipomotoretxt.getText().isEmpty() && !cilindritxt.getText().isEmpty() && !cilindratatxt.getText().isEmpty() && !nomecostruttoremotoretxt.getText().isEmpty() && !sedefabbricamotoretxt.getText().isEmpty() && !codicecambiotxt.getText().isEmpty() && !costocambiotxt.getText().isEmpty() && !marcetxt.getText().isEmpty() && !nomecostruttorecambiotxt.getText().isEmpty() && !sedefabbricacambiotxt.getText().isEmpty() && !codicetelaiotxt.getText().isEmpty() && !costotelaiotxt.getText().isEmpty() && !materialetxt.getText().isEmpty() && !pesotxt.getText().isEmpty() && !nomecostruttoretelaiotxt.getText().isEmpty() && !sedefabbricatelaiotxt.getText().isEmpty() && !DataAnno1.isEmpty() && !DataMese1.isEmpty() && !DataGiorno1.isEmpty() && !DataAnno2.isEmpty() && !DataMese2.isEmpty() && !DataGiorno2.isEmpty() && !DataAnno3.isEmpty() && !DataMese3.isEmpty() && !DataGiorno3.isEmpty()) btnInserisciVettura.setEnabled(true);
		        if(nomecostruttorecambiotxt.getText().isEmpty()) btnInserisciVettura.setEnabled(false);
		    }
		});

		sedefabbricacambiotxt.addModifyListener(new ModifyListener() {
		    public void modifyText(ModifyEvent e) {
		    	if(!codicevetturatxt.getText().isEmpty() && !codicemotoretxt.getText().isEmpty() && !costomotoretxt.getText().isEmpty() && !tipomotoretxt.getText().isEmpty() && !cilindritxt.getText().isEmpty() && !cilindratatxt.getText().isEmpty() && !nomecostruttoremotoretxt.getText().isEmpty() && !sedefabbricamotoretxt.getText().isEmpty() && !codicecambiotxt.getText().isEmpty() && !costocambiotxt.getText().isEmpty() && !marcetxt.getText().isEmpty() && !nomecostruttorecambiotxt.getText().isEmpty() && !sedefabbricacambiotxt.getText().isEmpty() && !codicetelaiotxt.getText().isEmpty() && !costotelaiotxt.getText().isEmpty() && !materialetxt.getText().isEmpty() && !pesotxt.getText().isEmpty() && !nomecostruttoretelaiotxt.getText().isEmpty() && !sedefabbricatelaiotxt.getText().isEmpty() && !DataAnno1.isEmpty() && !DataMese1.isEmpty() && !DataGiorno1.isEmpty() && !DataAnno2.isEmpty() && !DataMese2.isEmpty() && !DataGiorno2.isEmpty() && !DataAnno3.isEmpty() && !DataMese3.isEmpty() && !DataGiorno3.isEmpty()) btnInserisciVettura.setEnabled(true);
		        if(sedefabbricacambiotxt.getText().isEmpty()) btnInserisciVettura.setEnabled(false);
		    }
		});

		codicetelaiotxt.addModifyListener(new ModifyListener() {
		    public void modifyText(ModifyEvent e) {
		    	if(!codicevetturatxt.getText().isEmpty() && !codicemotoretxt.getText().isEmpty() && !costomotoretxt.getText().isEmpty() && !tipomotoretxt.getText().isEmpty() && !cilindritxt.getText().isEmpty() && !cilindratatxt.getText().isEmpty() && !nomecostruttoremotoretxt.getText().isEmpty() && !sedefabbricamotoretxt.getText().isEmpty() && !codicecambiotxt.getText().isEmpty() && !costocambiotxt.getText().isEmpty() && !marcetxt.getText().isEmpty() && !nomecostruttorecambiotxt.getText().isEmpty() && !sedefabbricacambiotxt.getText().isEmpty() && !codicetelaiotxt.getText().isEmpty() && !costotelaiotxt.getText().isEmpty() && !materialetxt.getText().isEmpty() && !pesotxt.getText().isEmpty() && !nomecostruttoretelaiotxt.getText().isEmpty() && !sedefabbricatelaiotxt.getText().isEmpty() && !DataAnno1.isEmpty() && !DataMese1.isEmpty() && !DataGiorno1.isEmpty() && !DataAnno2.isEmpty() && !DataMese2.isEmpty() && !DataGiorno2.isEmpty() && !DataAnno3.isEmpty() && !DataMese3.isEmpty() && !DataGiorno3.isEmpty()) btnInserisciVettura.setEnabled(true);
		        if(codicetelaiotxt.getText().isEmpty()) btnInserisciVettura.setEnabled(false);
		    }
		});

		costotelaiotxt.addModifyListener(new ModifyListener() {
		    public void modifyText(ModifyEvent e) {
		    	if(!codicevetturatxt.getText().isEmpty() && !codicemotoretxt.getText().isEmpty() && !costomotoretxt.getText().isEmpty() && !tipomotoretxt.getText().isEmpty() && !cilindritxt.getText().isEmpty() && !cilindratatxt.getText().isEmpty() && !nomecostruttoremotoretxt.getText().isEmpty() && !sedefabbricamotoretxt.getText().isEmpty() && !codicecambiotxt.getText().isEmpty() && !costocambiotxt.getText().isEmpty() && !marcetxt.getText().isEmpty() && !nomecostruttorecambiotxt.getText().isEmpty() && !sedefabbricacambiotxt.getText().isEmpty() && !codicetelaiotxt.getText().isEmpty() && !costotelaiotxt.getText().isEmpty() && !materialetxt.getText().isEmpty() && !pesotxt.getText().isEmpty() && !nomecostruttoretelaiotxt.getText().isEmpty() && !sedefabbricatelaiotxt.getText().isEmpty() && !DataAnno1.isEmpty() && !DataMese1.isEmpty() && !DataGiorno1.isEmpty() && !DataAnno2.isEmpty() && !DataMese2.isEmpty() && !DataGiorno2.isEmpty() && !DataAnno3.isEmpty() && !DataMese3.isEmpty() && !DataGiorno3.isEmpty()) btnInserisciVettura.setEnabled(true);
		        if(costotelaiotxt.getText().isEmpty()) btnInserisciVettura.setEnabled(false);
		    }
		});

		materialetxt.addModifyListener(new ModifyListener() {
		    public void modifyText(ModifyEvent e) {
		    	if(!codicevetturatxt.getText().isEmpty() && !codicemotoretxt.getText().isEmpty() && !costomotoretxt.getText().isEmpty() && !tipomotoretxt.getText().isEmpty() && !cilindritxt.getText().isEmpty() && !cilindratatxt.getText().isEmpty() && !nomecostruttoremotoretxt.getText().isEmpty() && !sedefabbricamotoretxt.getText().isEmpty() && !codicecambiotxt.getText().isEmpty() && !costocambiotxt.getText().isEmpty() && !marcetxt.getText().isEmpty() && !nomecostruttorecambiotxt.getText().isEmpty() && !sedefabbricacambiotxt.getText().isEmpty() && !codicetelaiotxt.getText().isEmpty() && !costotelaiotxt.getText().isEmpty() && !materialetxt.getText().isEmpty() && !pesotxt.getText().isEmpty() && !nomecostruttoretelaiotxt.getText().isEmpty() && !sedefabbricatelaiotxt.getText().isEmpty() && !DataAnno1.isEmpty() && !DataMese1.isEmpty() && !DataGiorno1.isEmpty() && !DataAnno2.isEmpty() && !DataMese2.isEmpty() && !DataGiorno2.isEmpty() && !DataAnno3.isEmpty() && !DataMese3.isEmpty() && !DataGiorno3.isEmpty()) btnInserisciVettura.setEnabled(true);
		        if(materialetxt.getText().isEmpty()) btnInserisciVettura.setEnabled(false);
		    }
		});

		pesotxt.addModifyListener(new ModifyListener() {
		    public void modifyText(ModifyEvent e) {
		    	if(!codicevetturatxt.getText().isEmpty() && !codicemotoretxt.getText().isEmpty() && !costomotoretxt.getText().isEmpty() && !tipomotoretxt.getText().isEmpty() && !cilindritxt.getText().isEmpty() && !cilindratatxt.getText().isEmpty() && !nomecostruttoremotoretxt.getText().isEmpty() && !sedefabbricamotoretxt.getText().isEmpty() && !codicecambiotxt.getText().isEmpty() && !costocambiotxt.getText().isEmpty() && !marcetxt.getText().isEmpty() && !nomecostruttorecambiotxt.getText().isEmpty() && !sedefabbricacambiotxt.getText().isEmpty() && !codicetelaiotxt.getText().isEmpty() && !costotelaiotxt.getText().isEmpty() && !materialetxt.getText().isEmpty() && !pesotxt.getText().isEmpty() && !nomecostruttoretelaiotxt.getText().isEmpty() && !sedefabbricatelaiotxt.getText().isEmpty() && !DataAnno1.isEmpty() && !DataMese1.isEmpty() && !DataGiorno1.isEmpty() && !DataAnno2.isEmpty() && !DataMese2.isEmpty() && !DataGiorno2.isEmpty() && !DataAnno3.isEmpty() && !DataMese3.isEmpty() && !DataGiorno3.isEmpty()) btnInserisciVettura.setEnabled(true);
		        if(pesotxt.getText().isEmpty()) btnInserisciVettura.setEnabled(false);
		    }
		});

		nomecostruttoretelaiotxt.addModifyListener(new ModifyListener() {
		    public void modifyText(ModifyEvent e) {
		    	if(!codicevetturatxt.getText().isEmpty() && !codicemotoretxt.getText().isEmpty() && !costomotoretxt.getText().isEmpty() && !tipomotoretxt.getText().isEmpty() && !cilindritxt.getText().isEmpty() && !cilindratatxt.getText().isEmpty() && !nomecostruttoremotoretxt.getText().isEmpty() && !sedefabbricamotoretxt.getText().isEmpty() && !codicecambiotxt.getText().isEmpty() && !costocambiotxt.getText().isEmpty() && !marcetxt.getText().isEmpty() && !nomecostruttorecambiotxt.getText().isEmpty() && !sedefabbricacambiotxt.getText().isEmpty() && !codicetelaiotxt.getText().isEmpty() && !costotelaiotxt.getText().isEmpty() && !materialetxt.getText().isEmpty() && !pesotxt.getText().isEmpty() && !nomecostruttoretelaiotxt.getText().isEmpty() && !sedefabbricatelaiotxt.getText().isEmpty() && !DataAnno1.isEmpty() && !DataMese1.isEmpty() && !DataGiorno1.isEmpty() && !DataAnno2.isEmpty() && !DataMese2.isEmpty() && !DataGiorno2.isEmpty() && !DataAnno3.isEmpty() && !DataMese3.isEmpty() && !DataGiorno3.isEmpty()) btnInserisciVettura.setEnabled(true);
		        if(nomecostruttoretelaiotxt.getText().isEmpty()) btnInserisciVettura.setEnabled(false);
		    }
		});

		sedefabbricatelaiotxt.addModifyListener(new ModifyListener() {
		    public void modifyText(ModifyEvent e) {
		    	if(!codicevetturatxt.getText().isEmpty() && !codicemotoretxt.getText().isEmpty() && !costomotoretxt.getText().isEmpty() && !tipomotoretxt.getText().isEmpty() && !cilindritxt.getText().isEmpty() && !cilindratatxt.getText().isEmpty() && !nomecostruttoremotoretxt.getText().isEmpty() && !sedefabbricamotoretxt.getText().isEmpty() && !codicecambiotxt.getText().isEmpty() && !costocambiotxt.getText().isEmpty() && !marcetxt.getText().isEmpty() && !nomecostruttorecambiotxt.getText().isEmpty() && !sedefabbricacambiotxt.getText().isEmpty() && !codicetelaiotxt.getText().isEmpty() && !costotelaiotxt.getText().isEmpty() && !materialetxt.getText().isEmpty() && !pesotxt.getText().isEmpty() && !nomecostruttoretelaiotxt.getText().isEmpty() && !sedefabbricatelaiotxt.getText().isEmpty() && !DataAnno1.isEmpty() && !DataMese1.isEmpty() && !DataGiorno1.isEmpty() && !DataAnno2.isEmpty() && !DataMese2.isEmpty() && !DataGiorno2.isEmpty() && !DataAnno3.isEmpty() && !DataMese3.isEmpty() && !DataGiorno3.isEmpty()) btnInserisciVettura.setEnabled(true);
		        if(sedefabbricatelaiotxt.getText().isEmpty()) btnInserisciVettura.setEnabled(false);
		    }
		});

		

	}
	private void createResourceManager() {
		localResourceManager2 = new LocalResourceManager(JFaceResources.getResources(),shell2);
	}
	private void registraVetturaBottoneFunzione(){
	    try {
	        int controlloquery2;
	        int controlloquery2_1;
	        int controlloquery2_2;
	        int controlloquery2_3;
	        PreparedStatement preparedstatement;
	        PreparedStatement preparedstatement1;
	        PreparedStatement preparedstatement2;
	        PreparedStatement preparedstatement3;
	        basedati = new Database(login.databaseName,login.databaseUsername,login.databasePassword);
	        basedati.connect();

	        String sql = "INSERT INTO basedidati.vettura (codice, modello, totale_punti) VALUES (?, ?, 0)";
	        preparedstatement = basedati.getConnection().prepareStatement(sql);
	        preparedstatement.setString(1, codicevetturatxt.getText());
	        preparedstatement.setString(2, modellovetturatxt.getText());
	        preparedstatement.addBatch();

	        sql = "INSERT INTO basedidati.componente (codice, tipo, data_installazione, costo, tipo_motore, marce, materiale, cilindri, cilindrata, peso, codice_vettura, nome_costruttore, sede_fabbrica) VALUES (?, ?, ?, ?, ?, NULL, NULL, ?, ?, NULL, ?, ?, ?)";
	        preparedstatement1 = basedati.getConnection().prepareStatement(sql);
	        preparedstatement1.setString(1, codicemotoretxt.getText());
	        preparedstatement1.setString(2, "Motore");
	        preparedstatement1.setString(3, DataAnno1+"-"+DataMese1+"-"+DataGiorno1);
	        preparedstatement1.setString(4, costomotoretxt.getText());
	        preparedstatement1.setString(5, tipomotoretxt.getText());
	        preparedstatement1.setString(6, cilindritxt.getText());
	        preparedstatement1.setString(7, cilindratatxt.getText());
	        preparedstatement1.setString(8, codicevetturatxt.getText());
	        preparedstatement1.setString(9, nomecostruttoremotoretxt.getText());
	        preparedstatement1.setString(10, sedefabbricamotoretxt.getText());
	        preparedstatement1.addBatch();

	        sql = "INSERT INTO basedidati.componente (codice, tipo, data_installazione, costo, tipo_motore, marce, materiale, cilindri, cilindrata, peso, codice_vettura, nome_costruttore, sede_fabbrica) VALUES (?, ?, ?, ?, NULL, ?, NULL, NULL, NULL, NULL, ?, ?, ?)";
	        preparedstatement2 = basedati.getConnection().prepareStatement(sql);
	        preparedstatement2.setString(1, codicecambiotxt.getText());
	        preparedstatement2.setString(2, "Cambio");
	        preparedstatement2.setString(3, DataAnno2+"-"+DataMese2+"-"+DataGiorno2);
	        preparedstatement2.setString(4, costocambiotxt.getText());
	        preparedstatement2.setString(5, marcetxt.getText());
	        preparedstatement2.setString(6, codicevetturatxt.getText());
	        preparedstatement2.setString(7, nomecostruttorecambiotxt.getText());
	        preparedstatement2.setString(8, sedefabbricacambiotxt.getText());
	        preparedstatement2.addBatch();
	        
	        sql = "INSERT INTO basedidati.componente (codice, tipo, data_installazione, costo, tipo_motore, marce, materiale, cilindri, cilindrata, peso, codice_vettura, nome_costruttore, sede_fabbrica) VALUES (?, ?, ?, ?, NULL, NULL, ?, NULL, NULL, ?, ?, ?, ?)";
	        preparedstatement3 = basedati.getConnection().prepareStatement(sql);
	        preparedstatement3.setString(1, codicetelaiotxt.getText());
	        preparedstatement3.setString(2, "Telaio");
	        preparedstatement3.setString(3, DataAnno3+"-"+DataMese3+"-"+DataGiorno3);
	        preparedstatement3.setString(4, costotelaiotxt.getText());
	        preparedstatement3.setString(5, materialetxt.getText());
	        preparedstatement3.setString(6, pesotxt.getText());
	        preparedstatement3.setString(7, codicevetturatxt.getText());
	        preparedstatement3.setString(8, nomecostruttoretelaiotxt.getText());
	        preparedstatement3.setString(9, sedefabbricatelaiotxt.getText());
	        
	        controlloquery2 = preparedstatement.executeUpdate();
	        controlloquery2_1 = preparedstatement1.executeUpdate();
	        controlloquery2_2 = preparedstatement2.executeUpdate();
	        controlloquery2_3 = preparedstatement3.executeUpdate();
	        preparedstatement.close();
	        preparedstatement1.close();
	        preparedstatement2.close();
	        preparedstatement3.close();

	        if(controlloquery2> 0 && controlloquery2_1 > 0 && controlloquery2_2 > 0 && controlloquery2_3 > 0) {
	            successo.main(null);
	        }
	        basedati.close();
	    }catch(SQLIntegrityConstraintViolationException e){
	    	e.printStackTrace();
	        fallimento2.main(null);
	    }catch(Exception e) {
	    	fallimento4_1.main(null);
	    	e.printStackTrace();
	    }
	}
}
