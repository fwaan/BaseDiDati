import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.SWT;
import org.eclipse.jface.resource.LocalResourceManager;
import org.eclipse.jface.resource.JFaceResources;

import java.sql.*;
import java.sql.PreparedStatement;
import java.sql.SQLIntegrityConstraintViolationException;

import org.eclipse.jface.resource.FontDescriptor;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.DateTime;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.ModifyEvent;

public class query3 {

	private Database basedati;
	protected static Shell shell3;
	private LocalResourceManager localResourceManager;
	private final FormToolkit formToolkit = new FormToolkit(Display.getDefault());
	private Text codicepilotatxt;
	private Text nomepilotatxt;
	private Text cognomepilotatxt;
	private Text licenzeprotxt;
	private Text codicescuderiapilotatxt;
	private Text codicevetturapilotatxt;
	public int selection = -1;
	private String DataAnno1 = "";
	private String DataMese1 = "";
	private String DataGiorno1 = "";
	private String DataAnno2 = "";
	private String DataMese2 = "";
	private String DataGiorno2 = "";
	private boolean GM;
	private Text nazionalitatxt;

	public static void main(String[] args) {
		try {
			if(shell3 == null || shell3.isDisposed())
			{
				/**
				 * Launch the application.
				 * @param args
				 * @wbp.parser.entryPoint
				 */
				query3 window = new query3();
				window.open();
			}
			else {
				shell3.forceActive();
				shell3.setMinimized(false);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 * @wbp.parser.entryPoint
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell3.open();
		shell3.layout();
		while (!shell3.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 * @wbp.parser.entryPoint
	 */
	protected void createContents() {
		shell3 = new Shell();
		createResourceManager();
		shell3.setImage(null);
		shell3.setSize(750, 689);
		
		Label lblAggiuntaPilota = new Label(shell3, SWT.NONE);
		lblAggiuntaPilota.setAlignment(SWT.CENTER);
		lblAggiuntaPilota.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 24, SWT.BOLD)));
		lblAggiuntaPilota.setBounds(10, 10, 714, 121);
		lblAggiuntaPilota.setText("AGGIUNTA PILOTA");
		
		Label lblCodicePilota = new Label(shell3, SWT.NONE);
		lblCodicePilota.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 11, SWT.BOLD)));
		lblCodicePilota.setBounds(10, 137, 193, 32);
		formToolkit.adapt(lblCodicePilota, true, true);
		lblCodicePilota.setText("CODICE PILOTA");
		
		Label lblNomePilota = new Label(shell3, SWT.NONE);
		lblNomePilota.setText("NOME");
		lblNomePilota.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 11, SWT.BOLD)));
		lblNomePilota.setBounds(10, 175, 193, 32);
		formToolkit.adapt(lblNomePilota, true, true);
		
		Label lblCognomePilota = new Label(shell3, SWT.NONE);
		lblCognomePilota.setText("COGNOME");
		lblCognomePilota.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 11, SWT.BOLD)));
		lblCognomePilota.setBounds(10, 213, 193, 32);
		formToolkit.adapt(lblCognomePilota, true, true);
		
		codicepilotatxt = new Text(shell3, SWT.BORDER);
		
		codicepilotatxt.setBounds(209, 138, 515, 32);
		formToolkit.adapt(codicepilotatxt, true, true);
		
		nomepilotatxt = new Text(shell3, SWT.BORDER);
		nomepilotatxt.setBounds(209, 176, 515, 32);
		formToolkit.adapt(nomepilotatxt, true, true);
		
		cognomepilotatxt = new Text(shell3, SWT.BORDER);
		cognomepilotatxt.setBounds(209, 214, 515, 32);
		formToolkit.adapt(cognomepilotatxt, true, true);
		
		Label lblNazionalita = new Label(shell3, SWT.NONE);
		lblNazionalita.setText("NAZIONALITA");
		lblNazionalita.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 11, SWT.BOLD)));
		lblNazionalita.setBounds(10, 251, 193, 32);
		formToolkit.adapt(lblNazionalita, true, true);
		
		nazionalitatxt = new Text(shell3, SWT.BORDER);
		
		nazionalitatxt.setBounds(209, 251, 515, 32);
		formToolkit.adapt(nazionalitatxt, true, true);
		Button btnAggiungiPilota = new Button(shell3, SWT.NONE);
		btnAggiungiPilota.setEnabled(false);
		btnAggiungiPilota.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				aggiuntaPilotaBottoneFunzione();
			}
		});
		btnAggiungiPilota.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 26, SWT.BOLD)));
		btnAggiungiPilota.setBounds(10, 555, 714, 85);
		formToolkit.adapt(btnAggiungiPilota, true, true);
		btnAggiungiPilota.setText("AGGIUNGI");
		
		Label lblDataNascitaPilota = new Label(shell3, SWT.NONE);
		lblDataNascitaPilota.setText("DATA DI NASCITA");
		lblDataNascitaPilota.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 11, SWT.BOLD)));
		lblDataNascitaPilota.setBounds(10, 289, 193, 32);
		formToolkit.adapt(lblDataNascitaPilota, true, true);
		
		DateTime datanascitapilota = new DateTime(shell3, SWT.BORDER);
		datanascitapilota.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				DataAnno1 = Integer.toString(datanascitapilota.getYear());
				DataMese1 = Integer.toString(datanascitapilota.getMonth() + 1);
				DataGiorno1 = Integer.toString(datanascitapilota.getDay());
			}
		});
		datanascitapilota.setBounds(209, 289, 515, 32);
		formToolkit.adapt(datanascitapilota);
		formToolkit.paintBordersFor(datanascitapilota);
		
		Label lblTipoPilota = new Label(shell3, SWT.NONE);
		lblTipoPilota.setText("TIPO");
		lblTipoPilota.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 11, SWT.BOLD)));
		lblTipoPilota.setBounds(10, 327, 193, 32);
		formToolkit.adapt(lblTipoPilota, true, true);
		
		Label lblLicenze = new Label(shell3, SWT.NONE);
		lblLicenze.setText("LICENZE");
		lblLicenze.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 11, SWT.BOLD)));
		lblLicenze.setBounds(10, 365, 193, 32);
		formToolkit.adapt(lblLicenze, true, true);
		
		licenzeprotxt = new Text(shell3, SWT.BORDER);
		licenzeprotxt.setEnabled(false);
		licenzeprotxt.setBounds(209, 366, 515, 32);
		formToolkit.adapt(licenzeprotxt, true, true);
		
		Label lblGentlemanDriver = new Label(shell3, SWT.NONE);
		lblGentlemanDriver.setText("GENTLEMAN DRIVER");
		lblGentlemanDriver.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 11, SWT.BOLD)));
		lblGentlemanDriver.setBounds(10, 403, 193, 32);
		formToolkit.adapt(lblGentlemanDriver, true, true);
		
		Button btnSi = new Button(shell3, SWT.CHECK);
		btnSi.setEnabled(false);
		btnSi.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				GM=btnSi.getSelection();
			}
		});
		btnSi.setBounds(209, 398, 517, 32);
		formToolkit.adapt(btnSi, true, true);
		
		Combo combo = new Combo(shell3, SWT.READ_ONLY);
		combo.setItems(new String[] {"PRO", "AM"});
		combo.setBounds(209, 327, 515, 32);
		formToolkit.adapt(combo);
		formToolkit.paintBordersFor(combo);
		
		Label lblDataLicenza = new Label(shell3, SWT.NONE);
		lblDataLicenza.setText("DATA LICENZA");
		lblDataLicenza.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 11, SWT.BOLD)));
		lblDataLicenza.setBounds(10, 441, 193, 32);
		formToolkit.adapt(lblDataLicenza, true, true);
		
		DateTime datalicenzapilota = new DateTime(shell3, SWT.BORDER);
		datalicenzapilota.setEnabled(false);
		
		datalicenzapilota.setBounds(209, 441, 515, 32);
		formToolkit.adapt(datalicenzapilota);
		formToolkit.paintBordersFor(datalicenzapilota);
		
		Label lblCodiceScuderia = new Label(shell3, SWT.NONE);
		lblCodiceScuderia.setText("CODICE SCUDERIA");
		lblCodiceScuderia.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 11, SWT.BOLD)));
		lblCodiceScuderia.setBounds(10, 479, 193, 32);
		formToolkit.adapt(lblCodiceScuderia, true, true);
		
		Label lblCodiceVettura = new Label(shell3, SWT.NONE);
		lblCodiceVettura.setText("CODICE VETTURA");
		lblCodiceVettura.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 11, SWT.BOLD)));
		lblCodiceVettura.setBounds(10, 517, 193, 32);
		formToolkit.adapt(lblCodiceVettura, true, true);
		
		codicescuderiapilotatxt = new Text(shell3, SWT.BORDER);
		codicescuderiapilotatxt.setBounds(209, 479, 515, 32);
		formToolkit.adapt(codicescuderiapilotatxt, true, true);
		
		codicevetturapilotatxt = new Text(shell3, SWT.BORDER);
		codicevetturapilotatxt.setBounds(209, 517, 515, 32);
		formToolkit.adapt(codicevetturapilotatxt, true, true);
		
		
		
		combo.addSelectionListener(new SelectionAdapter() {
		    @Override
		    public void widgetSelected(SelectionEvent e) {
		        selection = combo.getSelectionIndex();
				if(combo.getSelectionIndex() < 0) btnAggiungiPilota.setEnabled(false);
		        if(selection<=0) {
		        	btnAggiungiPilota.setEnabled(false);
		        	if(!nazionalitatxt.getText().isEmpty() &&!codicepilotatxt.getText().isEmpty() && !nomepilotatxt.getText().isEmpty() && !cognomepilotatxt.getText().isEmpty() && !DataAnno1.isEmpty() && !DataMese1.isEmpty() && !DataGiorno1.isEmpty() && combo.getSelectionIndex() >= 0 && !codicescuderiapilotatxt.getText().isEmpty() && !codicevetturapilotatxt.getText().isEmpty() && !licenzeprotxt.getText().isEmpty()) btnAggiungiPilota.setEnabled(true);
		        	licenzeprotxt.setEnabled(true);
		            datalicenzapilota.setEnabled(false);
		            btnSi.setEnabled(false);
		        }
		        else if(selection==1) {
		        	btnAggiungiPilota.setEnabled(false);
		        	if(!nazionalitatxt.getText().isEmpty() &&!codicepilotatxt.getText().isEmpty() && !nomepilotatxt.getText().isEmpty() && !cognomepilotatxt.getText().isEmpty() && !DataAnno1.isEmpty() && !DataMese1.isEmpty() && !DataGiorno1.isEmpty() && combo.getSelectionIndex() >= 0 && !codicescuderiapilotatxt.getText().isEmpty() && !codicevetturapilotatxt.getText().isEmpty() && !DataAnno1.isEmpty() && !DataMese1.isEmpty() && !DataGiorno1.isEmpty() && !DataAnno2.isEmpty() && !DataMese2.isEmpty() && !DataGiorno2.isEmpty()) btnAggiungiPilota.setEnabled(true);
		        	licenzeprotxt.setEnabled(false);
		            datalicenzapilota.setEnabled(true);
		            btnSi.setEnabled(true);
		        }
		    }
		});
		datalicenzapilota.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				DataAnno2 = Integer.toString(datalicenzapilota.getYear());
				DataMese2 = Integer.toString(datalicenzapilota.getMonth() + 1);
				DataGiorno2 = Integer.toString(datalicenzapilota.getDay());
			}
		});
		codicepilotatxt.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				if(selection==0) {
					if(!nazionalitatxt.getText().isEmpty() &&!codicepilotatxt.getText().isEmpty() && !nomepilotatxt.getText().isEmpty() && !cognomepilotatxt.getText().isEmpty() && !DataAnno1.isEmpty() && !DataMese1.isEmpty() && !DataGiorno1.isEmpty() && combo.getSelectionIndex() >= 0 && !codicescuderiapilotatxt.getText().isEmpty() && !codicevetturapilotatxt.getText().isEmpty() && !licenzeprotxt.getText().isEmpty()) btnAggiungiPilota.setEnabled(true);
				}
				if(selection==1) {
					if(!nazionalitatxt.getText().isEmpty() &&!codicepilotatxt.getText().isEmpty() && !nomepilotatxt.getText().isEmpty() && !cognomepilotatxt.getText().isEmpty() && !DataAnno1.isEmpty() && !DataMese1.isEmpty() && !DataGiorno1.isEmpty() && combo.getSelectionIndex() >= 0 && !codicescuderiapilotatxt.getText().isEmpty() && !codicevetturapilotatxt.getText().isEmpty() && !DataAnno2.isEmpty() && !DataMese2.isEmpty() && !DataGiorno2.isEmpty()) btnAggiungiPilota.setEnabled(true);
				}
				//if(!codicepilotatxt.getText().isEmpty() && !nomepilotatxt.getText().isEmpty() && !cognomepilotatxt.getText().isEmpty() && !DataAnno1.isEmpty() && !DataMese1.isEmpty() && !DataGiorno1.isEmpty() && combo.getSelectionIndex() >= 0 && !codicescuderiapilotatxt.getText().isEmpty() && !codicevetturapilotatxt.getText().isEmpty()) btnAggiungiPilota.setEnabled(true);
				if(codicepilotatxt.getText().isEmpty()) btnAggiungiPilota.setEnabled(false);
			}
		});
		nomepilotatxt.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				if(selection==0) {
					if(!nazionalitatxt.getText().isEmpty() &&!codicepilotatxt.getText().isEmpty() && !nomepilotatxt.getText().isEmpty() && !cognomepilotatxt.getText().isEmpty() && !DataAnno1.isEmpty() && !DataMese1.isEmpty() && !DataGiorno1.isEmpty() && combo.getSelectionIndex() >= 0 && !codicescuderiapilotatxt.getText().isEmpty() && !codicevetturapilotatxt.getText().isEmpty() && !licenzeprotxt.getText().isEmpty()) btnAggiungiPilota.setEnabled(true);
				}
				if(selection==1) {
					if(!nazionalitatxt.getText().isEmpty() &&!codicepilotatxt.getText().isEmpty() && !nomepilotatxt.getText().isEmpty() && !cognomepilotatxt.getText().isEmpty() && !DataAnno1.isEmpty() && !DataMese1.isEmpty() && !DataGiorno1.isEmpty() && combo.getSelectionIndex() >= 0 && !codicescuderiapilotatxt.getText().isEmpty() && !codicevetturapilotatxt.getText().isEmpty() && !DataAnno2.isEmpty() && !DataMese2.isEmpty() && !DataGiorno2.isEmpty()) btnAggiungiPilota.setEnabled(true);
				}
				//if(!codicepilotatxt.getText().isEmpty() && !nomepilotatxt.getText().isEmpty() && !cognomepilotatxt.getText().isEmpty() && !DataAnno1.isEmpty() && !DataMese1.isEmpty() && !DataGiorno1.isEmpty() && combo.getSelectionIndex() >= 0 && !codicescuderiapilotatxt.getText().isEmpty() && !codicevetturapilotatxt.getText().isEmpty()) btnAggiungiPilota.setEnabled(true);
				if(nomepilotatxt.getText().isEmpty()) btnAggiungiPilota.setEnabled(false);
			}
		});
		cognomepilotatxt.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				if(selection==0) {
					if(!nazionalitatxt.getText().isEmpty() &&!codicepilotatxt.getText().isEmpty() && !nomepilotatxt.getText().isEmpty() && !cognomepilotatxt.getText().isEmpty() && !DataAnno1.isEmpty() && !DataMese1.isEmpty() && !DataGiorno1.isEmpty() && combo.getSelectionIndex() >= 0 && !codicescuderiapilotatxt.getText().isEmpty() && !codicevetturapilotatxt.getText().isEmpty() && !licenzeprotxt.getText().isEmpty()) btnAggiungiPilota.setEnabled(true);
				}
				if(selection==1) {
					if(!nazionalitatxt.getText().isEmpty() &&!codicepilotatxt.getText().isEmpty() && !nomepilotatxt.getText().isEmpty() && !cognomepilotatxt.getText().isEmpty() && !DataAnno1.isEmpty() && !DataMese1.isEmpty() && !DataGiorno1.isEmpty() && combo.getSelectionIndex() >= 0 && !codicescuderiapilotatxt.getText().isEmpty() && !codicevetturapilotatxt.getText().isEmpty() && !DataAnno2.isEmpty() && !DataMese2.isEmpty() && !DataGiorno2.isEmpty()) btnAggiungiPilota.setEnabled(true);
				}
				//if(!codicepilotatxt.getText().isEmpty() && !nomepilotatxt.getText().isEmpty() && !cognomepilotatxt.getText().isEmpty() && !DataAnno1.isEmpty() && !DataMese1.isEmpty() && !DataGiorno1.isEmpty() && combo.getSelectionIndex() >= 0 && !codicescuderiapilotatxt.getText().isEmpty() && !codicevetturapilotatxt.getText().isEmpty()) btnAggiungiPilota.setEnabled(true);
				if(cognomepilotatxt.getText().isEmpty()) btnAggiungiPilota.setEnabled(false);
			}
		});
		codicescuderiapilotatxt.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				if(selection==0) {
					if(!nazionalitatxt.getText().isEmpty() &&!codicepilotatxt.getText().isEmpty() && !nomepilotatxt.getText().isEmpty() && !cognomepilotatxt.getText().isEmpty() && !DataAnno1.isEmpty() && !DataMese1.isEmpty() && !DataGiorno1.isEmpty() && combo.getSelectionIndex() >= 0 && !codicescuderiapilotatxt.getText().isEmpty() && !codicevetturapilotatxt.getText().isEmpty() && !licenzeprotxt.getText().isEmpty()) btnAggiungiPilota.setEnabled(true);
				}
				if(selection==1) {
					if(!nazionalitatxt.getText().isEmpty() &&!codicepilotatxt.getText().isEmpty() && !nomepilotatxt.getText().isEmpty() && !cognomepilotatxt.getText().isEmpty() && !DataAnno1.isEmpty() && !DataMese1.isEmpty() && !DataGiorno1.isEmpty() && combo.getSelectionIndex() >= 0 && !codicescuderiapilotatxt.getText().isEmpty() && !codicevetturapilotatxt.getText().isEmpty() && !DataAnno2.isEmpty() && !DataMese2.isEmpty() && !DataGiorno2.isEmpty()) btnAggiungiPilota.setEnabled(true);
				}
				//if(!codicepilotatxt.getText().isEmpty() && !nomepilotatxt.getText().isEmpty() && !cognomepilotatxt.getText().isEmpty() && !DataAnno1.isEmpty() && !DataMese1.isEmpty() && !DataGiorno1.isEmpty() && combo.getSelectionIndex() >= 0 && !codicescuderiapilotatxt.getText().isEmpty() && !codicevetturapilotatxt.getText().isEmpty()) btnAggiungiPilota.setEnabled(true);
				if(codicescuderiapilotatxt.getText().isEmpty()) btnAggiungiPilota.setEnabled(false);
			}
		});
		codicevetturapilotatxt.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				if(selection==0) {
					if(!nazionalitatxt.getText().isEmpty() &&!codicepilotatxt.getText().isEmpty() && !nomepilotatxt.getText().isEmpty() && !cognomepilotatxt.getText().isEmpty() && !DataAnno1.isEmpty() && !DataMese1.isEmpty() && !DataGiorno1.isEmpty() && combo.getSelectionIndex() >= 0 && !codicescuderiapilotatxt.getText().isEmpty() && !codicevetturapilotatxt.getText().isEmpty() && !licenzeprotxt.getText().isEmpty()) btnAggiungiPilota.setEnabled(true);
				}
				if(selection==1) {
					if(!nazionalitatxt.getText().isEmpty() &&!codicepilotatxt.getText().isEmpty() && !nomepilotatxt.getText().isEmpty() && !cognomepilotatxt.getText().isEmpty() && !DataAnno1.isEmpty() && !DataMese1.isEmpty() && !DataGiorno1.isEmpty() && combo.getSelectionIndex() >= 0 && !codicescuderiapilotatxt.getText().isEmpty() && !codicevetturapilotatxt.getText().isEmpty() && !DataAnno2.isEmpty() && !DataMese2.isEmpty() && !DataGiorno2.isEmpty()) btnAggiungiPilota.setEnabled(true);
				}
				//if(!codicepilotatxt.getText().isEmpty() && !nomepilotatxt.getText().isEmpty() && !cognomepilotatxt.getText().isEmpty() && !DataAnno1.isEmpty() && !DataMese1.isEmpty() && !DataGiorno1.isEmpty() && combo.getSelectionIndex() >= 0 && !codicescuderiapilotatxt.getText().isEmpty() && !codicevetturapilotatxt.getText().isEmpty()) btnAggiungiPilota.setEnabled(true);
				if(codicevetturapilotatxt.getText().isEmpty()) btnAggiungiPilota.setEnabled(false);
			}
		});
		licenzeprotxt.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				if(selection==0) {
					if(!nazionalitatxt.getText().isEmpty() &&!codicepilotatxt.getText().isEmpty() && !nomepilotatxt.getText().isEmpty() && !cognomepilotatxt.getText().isEmpty() && !DataAnno1.isEmpty() && !DataMese1.isEmpty() && !DataGiorno1.isEmpty() && combo.getSelectionIndex() >= 0 && !codicescuderiapilotatxt.getText().isEmpty() && !codicevetturapilotatxt.getText().isEmpty() && !licenzeprotxt.getText().isEmpty()) btnAggiungiPilota.setEnabled(true);
				}
				if(selection==1) {
					if(!nazionalitatxt.getText().isEmpty() &&!codicepilotatxt.getText().isEmpty() && !nomepilotatxt.getText().isEmpty() && !cognomepilotatxt.getText().isEmpty() && !DataAnno1.isEmpty() && !DataMese1.isEmpty() && !DataGiorno1.isEmpty() && combo.getSelectionIndex() >= 0 && !codicescuderiapilotatxt.getText().isEmpty() && !codicevetturapilotatxt.getText().isEmpty() && !DataAnno2.isEmpty() && !DataMese2.isEmpty() && !DataGiorno2.isEmpty()) btnAggiungiPilota.setEnabled(true);
				}
				//if(!codicepilotatxt.getText().isEmpty() && !nomepilotatxt.getText().isEmpty() && !cognomepilotatxt.getText().isEmpty() && !DataAnno1.isEmpty() && !DataMese1.isEmpty() && !DataGiorno1.isEmpty() && combo.getSelectionIndex() >= 0 && !codicescuderiapilotatxt.getText().isEmpty() && !codicevetturapilotatxt.getText().isEmpty()) btnAggiungiPilota.setEnabled(true);
				if(licenzeprotxt.getText().isEmpty()) btnAggiungiPilota.setEnabled(false);
			}
		});
		nazionalitatxt.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				if(selection==0) {
					if(!nazionalitatxt.getText().isEmpty() &&!codicepilotatxt.getText().isEmpty() && !nomepilotatxt.getText().isEmpty() && !cognomepilotatxt.getText().isEmpty() && !DataAnno1.isEmpty() && !DataMese1.isEmpty() && !DataGiorno1.isEmpty() && combo.getSelectionIndex() >= 0 && !codicescuderiapilotatxt.getText().isEmpty() && !codicevetturapilotatxt.getText().isEmpty() && !licenzeprotxt.getText().isEmpty()) btnAggiungiPilota.setEnabled(true);
				}
				if(selection==1) {
					if(!nazionalitatxt.getText().isEmpty() &&!codicepilotatxt.getText().isEmpty() && !nomepilotatxt.getText().isEmpty() && !cognomepilotatxt.getText().isEmpty() && !DataAnno1.isEmpty() && !DataMese1.isEmpty() && !DataGiorno1.isEmpty() && combo.getSelectionIndex() >= 0 && !codicescuderiapilotatxt.getText().isEmpty() && !codicevetturapilotatxt.getText().isEmpty() && !DataAnno2.isEmpty() && !DataMese2.isEmpty() && !DataGiorno2.isEmpty()) btnAggiungiPilota.setEnabled(true);
				}
				//if(!codicepilotatxt.getText().isEmpty() && !nomepilotatxt.getText().isEmpty() && !cognomepilotatxt.getText().isEmpty() && !DataAnno1.isEmpty() && !DataMese1.isEmpty() && !DataGiorno1.isEmpty() && combo.getSelectionIndex() >= 0 && !codicescuderiapilotatxt.getText().isEmpty() && !codicevetturapilotatxt.getText().isEmpty()) btnAggiungiPilota.setEnabled(true);
				if(nazionalitatxt.getText().isEmpty()) btnAggiungiPilota.setEnabled(false);
			}
		});
		

	}
	/**
	 * @wbp.parser.entryPoint
	 */
	private void createResourceManager() {
		localResourceManager = new LocalResourceManager(JFaceResources.getResources(),shell3);
	}
	private void aggiuntaPilotaBottoneFunzione(){
	    try {
	        int controlloquery1=0;
	        basedati = new Database(login.databaseName,login.databaseUsername,login.databasePassword);
	        basedati.connect();
	        PreparedStatement preparedstatement;
	        
	        // Controlla se esiste la scuderia
	        preparedstatement = basedati.getConnection().prepareStatement("SELECT COUNT(*) FROM basedidati.scuderia WHERE codice = ?");
	        preparedstatement.setString(1, codicescuderiapilotatxt.getText());
	        ResultSet rs = preparedstatement.executeQuery();
	        rs.next();
	        boolean existsScuderia = rs.getInt(1) > 0;
	        rs.close();
	        preparedstatement.close();

	        if (!existsScuderia) {
	            // Se la scuderia non esiste, mostra un messaggio di errore e termina la funzione
	            fallimento3.main(null);
	            return;
	        }

	     // Controlla se esiste già un pilota per la scuderia
	        preparedstatement = basedati.getConnection().prepareStatement("SELECT COUNT(*) FROM basedidati.pilota WHERE codice_scuderia = ?");
	        preparedstatement.setString(1, codicescuderiapilotatxt.getText());
	        rs = preparedstatement.executeQuery();
	        rs.next();
	        boolean existsPilot = rs.getInt(1) > 0;
	        rs.close();
	        preparedstatement.close();

	        // Dividi la stringa di nazionalità in un array
	        String[] nazionalitaArray = nazionalitatxt.getText().split(",");

	        for (String nazionalita : nazionalitaArray) {
	            // Controlla se la nazionalità esiste già
	            preparedstatement = basedati.getConnection().prepareStatement("SELECT * FROM basedidati.nazionalita WHERE nome = ?");
	            preparedstatement.setString(1, nazionalita);
	            rs = preparedstatement.executeQuery();

	            // Se la nazionalità non esiste, inseriscila
	            if (!rs.next()) {
	                preparedstatement = basedati.getConnection().prepareStatement("INSERT INTO basedidati.nazionalita (nome) VALUES (?)");
	                preparedstatement.setString(1, nazionalita);
	                preparedstatement.executeUpdate();
	            }
	            rs.close();
	            preparedstatement.close();
	        }

	        // Inserisci il pilota
	        if(selection==1) {
	            //AM
	            if(!GM) {
	                preparedstatement = basedati.getConnection().prepareStatement("INSERT INTO basedidati.pilota (codice, nome, cognome, data_nascita, data_licenza, gentleman_driver, licenze, tipo, codice_scuderia, codice_vettura) VALUES (?, ?, ?, ?, ?, 0, NULL, 'AM', ?, ?);");
	                preparedstatement.setString(1, codicepilotatxt.getText());
	                preparedstatement.setString(2, nomepilotatxt.getText());
	                preparedstatement.setString(3, cognomepilotatxt.getText());
	                preparedstatement.setString(4, DataAnno1+"-"+DataMese1+"-"+DataGiorno1);
	                preparedstatement.setString(5, DataAnno2+"-"+DataMese2+"-"+DataGiorno2);
	                preparedstatement.setString(6, codicescuderiapilotatxt.getText());
	                preparedstatement.setString(7, codicevetturapilotatxt.getText());
	                controlloquery1 = preparedstatement.executeUpdate();
	                preparedstatement.close();
	            }
	            //GM
	            if(GM && existsPilot) {
	                preparedstatement = basedati.getConnection().prepareStatement("INSERT INTO basedidati.pilota (codice, nome, cognome, data_nascita, data_licenza, gentleman_driver, licenze, tipo, codice_scuderia, codice_vettura) VALUES (?, ?, ?, ?, ?, 1, NULL, 'AM', ?, ?);");
	                preparedstatement.setString(1, codicepilotatxt.getText());
	                preparedstatement.setString(2, nomepilotatxt.getText());
	                preparedstatement.setString(3, cognomepilotatxt.getText());
	                preparedstatement.setString(4, DataAnno1+"-"+DataMese1+"-"+DataGiorno1);
	                preparedstatement.setString(5, DataAnno2+"-"+DataMese2+"-"+DataGiorno2);
	                preparedstatement.setString(6, codicescuderiapilotatxt.getText());
	                preparedstatement.setString(7, codicevetturapilotatxt.getText());
	                controlloquery1 = preparedstatement.executeUpdate();
	                preparedstatement.close();
	            } else if(GM && !existsPilot) {
	                // Se il pilota è un GM e esiste già un GM per la scuderia, vai a fallimento3_1.main()
	                fallimento3_1.main(null);
	                return;
	            }
	        }
	        //PRO
	        if(selection==0) {
	            preparedstatement = basedati.getConnection().prepareStatement("INSERT INTO basedidati.pilota (codice, nome, cognome, data_nascita, data_licenza, gentleman_driver, licenze, tipo, codice_scuderia, codice_vettura) VALUES (?, ?, ?, ?, NULL, NULL, ?, 'PRO', ?, ?);");
	            preparedstatement.setString(1, codicepilotatxt.getText());
	            preparedstatement.setString(2, nomepilotatxt.getText());
	            preparedstatement.setString(3, cognomepilotatxt.getText());
	            preparedstatement.setString(4, DataAnno1+"-"+DataMese1+"-"+DataGiorno1);
	            preparedstatement.setString(5, licenzeprotxt.getText());
	            preparedstatement.setString(6, codicescuderiapilotatxt.getText());
	            preparedstatement.setString(7, codicevetturapilotatxt.getText());
	            controlloquery1 = preparedstatement.executeUpdate();
	            preparedstatement.close();
	        }

	        // Inserisci l'origine per ogni nazionalità
	        for (String nazionalita : nazionalitaArray) {
	            preparedstatement = basedati.getConnection().prepareStatement("INSERT INTO basedidati.origine (codice_pilota, nome_nazionalita) VALUES (?,?)");
	            preparedstatement.setString(1, codicepilotatxt.getText());
	            preparedstatement.setString(2, nazionalita);
	            preparedstatement.executeUpdate();
	            preparedstatement.close();
	        }

	        if(controlloquery1>0) {
	            successo.main(null);
	        }
	        basedati.close();
	    }catch(SQLIntegrityConstraintViolationException e){
	        fallimento3.main(null);
	    }catch(Exception e) {
	    	fallimento4_1.main(null);
	        e.printStackTrace();
	    }
	}
}
