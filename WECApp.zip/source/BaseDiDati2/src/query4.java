import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.SWT;
import org.eclipse.jface.resource.LocalResourceManager;
import org.eclipse.jface.resource.JFaceResources;

import java.sql.PreparedStatement;
import java.sql.SQLIntegrityConstraintViolationException;

import org.eclipse.jface.resource.FontDescriptor;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.ModifyEvent;

public class query4 {

	private Database basedati;
	protected static Shell shell4;
	private LocalResourceManager localResourceManager;
	private final FormToolkit formToolkit = new FormToolkit(Display.getDefault());
	private Text codicescuderiatxt;
	private Text codicepilotatxt;
	private Text quotatxt;

	public static void main(String[] args) {
		try {
			if(shell4 == null || shell4.isDisposed())
			{
				/**
				 * Launch the application.
				 * @param args
				 * @wbp.parser.entryPoint
				 */
				query4 window = new query4();
				window.open();
			}
			else {
				shell4.forceActive();
				shell4.setMinimized(false);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 * @wbp.parser.entryPoint
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell4.open();
		shell4.layout();
		while (!shell4.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 * @wbp.parser.entryPoint
	 */
	protected void createContents() {
		shell4 = new Shell();
		createResourceManager();
		shell4.setImage(null);
		shell4.setSize(900, 369);
		
		Label lblRegistrazioneFinanziamento = new Label(shell4, SWT.NONE);
		lblRegistrazioneFinanziamento.setAlignment(SWT.CENTER);
		lblRegistrazioneFinanziamento.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 24, SWT.BOLD)));
		lblRegistrazioneFinanziamento.setBounds(10, 10, 864, 115);
		lblRegistrazioneFinanziamento.setText("REGISTRAZIONE FINANZIAMENTO");
		
		Label lblCodiceScuderia = new Label(shell4, SWT.NONE);
		lblCodiceScuderia.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 11, SWT.BOLD)));
		lblCodiceScuderia.setBounds(10, 131, 343, 32);
		formToolkit.adapt(lblCodiceScuderia, true, true);
		lblCodiceScuderia.setText("CODICE SCUDERIA");
		
		Label lblCodicePilota = new Label(shell4, SWT.NONE);
		lblCodicePilota.setText("CODICE PILOTA");
		lblCodicePilota.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 11, SWT.BOLD)));
		lblCodicePilota.setBounds(10, 169, 343, 32);
		formToolkit.adapt(lblCodicePilota, true, true);
		
		Label lblQuota = new Label(shell4, SWT.NONE);
		lblQuota.setText("QUOTA");
		lblQuota.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 11, SWT.BOLD)));
		lblQuota.setBounds(10, 207, 343, 32);
		formToolkit.adapt(lblQuota, true, true);
		
		codicescuderiatxt = new Text(shell4, SWT.BORDER);
		codicescuderiatxt.setBounds(359, 132, 515, 32);
		formToolkit.adapt(codicescuderiatxt, true, true);
		
		codicepilotatxt = new Text(shell4, SWT.BORDER);
		codicepilotatxt.setBounds(359, 170, 515, 32);
		formToolkit.adapt(codicepilotatxt, true, true);
		
		quotatxt = new Text(shell4, SWT.BORDER);
		quotatxt.setBounds(359, 208, 515, 32);
		formToolkit.adapt(quotatxt, true, true);
		
		Button btnRegistraFinanziamento = new Button(shell4, SWT.NONE);
		btnRegistraFinanziamento.setEnabled(false);
		btnRegistraFinanziamento.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				registraFinanziamentoBottoneFunzione();
			}
		});
		btnRegistraFinanziamento.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 26, SWT.BOLD)));
		btnRegistraFinanziamento.setBounds(10, 245, 864, 75);
		formToolkit.adapt(btnRegistraFinanziamento, true, true);
		btnRegistraFinanziamento.setText("REGISTRA");
		
		codicescuderiatxt.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				if(!codicescuderiatxt.getText().isEmpty() && !codicepilotatxt.getText().isEmpty() && !quotatxt.getText().isEmpty()) btnRegistraFinanziamento.setEnabled(true);
				if(codicescuderiatxt.getText().isEmpty()) btnRegistraFinanziamento.setEnabled(false);
			}
		});
		codicepilotatxt.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				if(!codicescuderiatxt.getText().isEmpty() && !codicepilotatxt.getText().isEmpty() && !quotatxt.getText().isEmpty()) btnRegistraFinanziamento.setEnabled(true);
				if(codicepilotatxt.getText().isEmpty()) btnRegistraFinanziamento.setEnabled(false);
			}
		});
		quotatxt.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				if(!codicescuderiatxt.getText().isEmpty() && !codicepilotatxt.getText().isEmpty() && !quotatxt.getText().isEmpty()) btnRegistraFinanziamento.setEnabled(true);
				if(quotatxt.getText().isEmpty()) btnRegistraFinanziamento.setEnabled(false);
			}
		});

	}
	/**
	 * @wbp.parser.entryPoint
	 */
	private void createResourceManager() {
		localResourceManager = new LocalResourceManager(JFaceResources.getResources(),shell4);
	}
	private void registraFinanziamentoBottoneFunzione(){
		try {
		    int controlloquery1;
		    PreparedStatement preparedstatement;
		    basedati = new Database(login.databaseName,login.databaseUsername,login.databasePassword);
		    basedati.connect();

		    // Prima query
		    preparedstatement = basedati.getConnection().prepareStatement("INSERT INTO basedidati.finanziamento (quota, codice_pilota, scuderia) VALUES (?, ?, ?);");
		    preparedstatement.setString(1, quotatxt.getText());
		    preparedstatement.setString(2, codicepilotatxt.getText());
		    preparedstatement.setString(3, codicescuderiatxt.getText());
		    controlloquery1 = preparedstatement.executeUpdate();

		    // Seconda query
		    preparedstatement = basedati.getConnection().prepareStatement("UPDATE basedidati.scuderia SET finanziamenti = finanziamenti + 1 WHERE codice = ?;");
		    preparedstatement.setString(1, codicescuderiatxt.getText());
		    controlloquery1 = preparedstatement.executeUpdate();

		    if(controlloquery1>0) {
		        successo.main(null);
		    }
		    preparedstatement.close();
		    basedati.close();
		} catch(SQLIntegrityConstraintViolationException e){
		    fallimento4.main(null);
		} catch(Exception e) {
			fallimento4_1.main(null);
		    e.printStackTrace();
		}

	}
}
