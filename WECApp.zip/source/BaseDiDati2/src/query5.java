import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.SWT;
import org.eclipse.jface.resource.LocalResourceManager;
import org.eclipse.jface.resource.JFaceResources;

import java.sql.*;

import org.eclipse.jface.resource.FontDescriptor;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.ModifyEvent;

public class query5 {

	private Database basedati;
	protected static Shell shell5;
	private LocalResourceManager localResourceManager;
	private final FormToolkit formToolkit = new FormToolkit(Display.getDefault());
	private Text codicevetturatxt;
	private Text codicegaratxt;

	public static void main(String[] args) {
		try {
			if(shell5 == null || shell5.isDisposed())
			{
				/**
				 * Launch the application.
				 * @param args
				 * @wbp.parser.entryPoint
				 */
				query5 window = new query5();
				window.open();
			}
			else {
				shell5.forceActive();
				shell5.setMinimized(false);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 * @wbp.parser.entryPoint
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell5.open();
		shell5.layout();
		while (!shell5.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 * @wbp.parser.entryPoint
	 */
	protected void createContents() {
		shell5 = new Shell();
		createResourceManager();
		shell5.setImage(null);
		shell5.setSize(750, 313);
		
		Label lblIscrizioneGara = new Label(shell5, SWT.NONE);
		lblIscrizioneGara.setAlignment(SWT.CENTER);
		lblIscrizioneGara.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 24, SWT.BOLD)));
		lblIscrizioneGara.setBounds(10, 10, 714, 92);
		lblIscrizioneGara.setText("ISCRIZIONE GARA");
		
		Label lblCodiceVettura = new Label(shell5, SWT.NONE);
		lblCodiceVettura.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 11, SWT.BOLD)));
		lblCodiceVettura.setBounds(10, 108, 228, 32);
		formToolkit.adapt(lblCodiceVettura, true, true);
		lblCodiceVettura.setText("CODICE VETTURA");
		
		Label lblCodiceGara = new Label(shell5, SWT.NONE);
		lblCodiceGara.setText("CODICE GARA");
		lblCodiceGara.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 11, SWT.BOLD)));
		lblCodiceGara.setBounds(10, 146, 228, 32);
		formToolkit.adapt(lblCodiceGara, true, true);
		
		codicevetturatxt = new Text(shell5, SWT.BORDER);
		
		codicevetturatxt.setBounds(244, 109, 480, 32);
		formToolkit.adapt(codicevetturatxt, true, true);
		
		codicegaratxt = new Text(shell5, SWT.BORDER);
		codicegaratxt.setBounds(244, 146, 480, 32);
		formToolkit.adapt(codicegaratxt, true, true);
		
		Button btnIscriviGaraVettura = new Button(shell5, SWT.NONE);
		btnIscriviGaraVettura.setEnabled(false);
		btnIscriviGaraVettura.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				registraIscrizioneBottoneFunzione();
			}
		});
		btnIscriviGaraVettura.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 26, SWT.BOLD)));
		btnIscriviGaraVettura.setBounds(10, 184, 714, 80);
		formToolkit.adapt(btnIscriviGaraVettura, true, true);
		btnIscriviGaraVettura.setText("ISCRIVI");
		
		codicevetturatxt.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				if(!codicevetturatxt.getText().isEmpty() && !codicegaratxt.getText().isEmpty()) btnIscriviGaraVettura.setEnabled(true);
				if(codicevetturatxt.getText().isEmpty()) btnIscriviGaraVettura.setEnabled(false);
			}
		});
		codicegaratxt.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				if(!codicevetturatxt.getText().isEmpty() && !codicegaratxt.getText().isEmpty()) btnIscriviGaraVettura.setEnabled(true);
				if(codicegaratxt.getText().isEmpty()) btnIscriviGaraVettura.setEnabled(false);
			}
		});

	}
	/**
	 * @wbp.parser.entryPoint
	 */
	private void createResourceManager() {
		localResourceManager = new LocalResourceManager(JFaceResources.getResources(),shell5);
	}
	private void registraIscrizioneBottoneFunzione(){
	    try {
	        ResultSet rs;
	        PreparedStatement preparedstatement;
	        basedati = new Database(login.databaseName,login.databaseUsername,login.databasePassword);
	        basedati.connect();

	        // Prima query
	        preparedstatement = basedati.getConnection().prepareStatement("SELECT 1 FROM basedidati.iscrizione WHERE codice_gara = ? AND codice_vettura = ?");
	        preparedstatement.setString(1, codicegaratxt.getText());
	        preparedstatement.setString(2, codicevetturatxt.getText());
	        rs = preparedstatement.executeQuery();

	        // Controlla se la query ha restituito almeno una riga
	        if (!rs.next()) {
	            // Se la riga non esiste, esegui la seconda query
	            preparedstatement = basedati.getConnection().prepareStatement("INSERT INTO basedidati.iscrizione (punti,motivo_ritiro,codice_gara,codice_vettura) VALUES('0',NULL,?,?);");
	            preparedstatement.setString(1, codicegaratxt.getText());
	            preparedstatement.setString(2, codicevetturatxt.getText());
	            int controlloquery1 = preparedstatement.executeUpdate();

	            if(controlloquery1>0) {
	                successo.main(null);
	            }
	        }
	        else {
	        	fallimento5_1.main(null);
	        }

	        rs.close();
	        preparedstatement.close();
	        basedati.close();
	    } catch(SQLIntegrityConstraintViolationException e){
	        fallimento5.main(null);
	    } catch(Exception e) {
	    	fallimento4_1.main(null);
	        e.printStackTrace();
	    }
	}
}
