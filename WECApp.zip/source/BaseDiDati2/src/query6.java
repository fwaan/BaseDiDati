import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.SWT;
import org.eclipse.jface.resource.LocalResourceManager;
import org.eclipse.jface.resource.JFaceResources;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLIntegrityConstraintViolationException;

import org.eclipse.jface.resource.FontDescriptor;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.ModifyEvent;

public class query6 {

	private Database basedati;
	boolean ritirato = false;
	private String motivoritirato;
	int selection = -1;
	protected static Shell shell6;
	private LocalResourceManager localResourceManager;
	private final FormToolkit formToolkit = new FormToolkit(Display.getDefault());
	private Text codicegaratxt;
	private Text codicevetturatxt;
	private Text puntiottenutitxt;

	public static void main(String[] args) {
		try {
			if(shell6 == null || shell6.isDisposed())
			{
				/**
				 * Launch the application.
				 * @param args
				 * @wbp.parser.entryPoint
				 */
				query6 window = new query6();
				window.open();
			}
			else {
				shell6.forceActive();
				shell6.setMinimized(false);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 * @wbp.parser.entryPoint
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell6.open();
		shell6.layout();
		while (!shell6.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 * @wbp.parser.entryPoint
	 */
	protected void createContents() {
		shell6 = new Shell();
		createResourceManager();
		shell6.setImage(null);
		shell6.setSize(1170, 432);
		
		Label lblRegistrazioneRisultatoGara = new Label(shell6, SWT.NONE);
		lblRegistrazioneRisultatoGara.setAlignment(SWT.CENTER);
		lblRegistrazioneRisultatoGara.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 24, SWT.BOLD)));
		lblRegistrazioneRisultatoGara.setBounds(10, 10, 1134, 110);
		lblRegistrazioneRisultatoGara.setText("REGISTRAZIONE RISULTATO VETTURA");
		
		Label lblCodiceGara = new Label(shell6, SWT.NONE);
		lblCodiceGara.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 11, SWT.BOLD)));
		lblCodiceGara.setBounds(10, 126, 210, 32);
		formToolkit.adapt(lblCodiceGara, true, true);
		lblCodiceGara.setText("CODICE GARA");
		
		Label lblCodiceVettura = new Label(shell6, SWT.NONE);
		lblCodiceVettura.setText("CODICE VETTURA");
		lblCodiceVettura.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 11, SWT.BOLD)));
		lblCodiceVettura.setBounds(10, 164, 210, 32);
		formToolkit.adapt(lblCodiceVettura, true, true);
		
		Label lblRitiro = new Label(shell6, SWT.NONE);
		lblRitiro.setText("RITIRO");
		lblRitiro.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 11, SWT.BOLD)));
		lblRitiro.setBounds(10, 202, 210, 32);
		formToolkit.adapt(lblRitiro, true, true);
		
		codicegaratxt = new Text(shell6, SWT.BORDER);
		codicegaratxt.setBounds(226, 126, 918, 32);
		formToolkit.adapt(codicegaratxt, true, true);
		
		codicevetturatxt = new Text(shell6, SWT.BORDER);
		codicevetturatxt.setBounds(226, 165, 918, 32);
		formToolkit.adapt(codicevetturatxt, true, true);
		
		Button btnRegistraRisultatoGara = new Button(shell6, SWT.NONE);
		btnRegistraRisultatoGara.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				registraIscrizioneBottoneFunzione();
			}
		});
		btnRegistraRisultatoGara.setEnabled(false);
		btnRegistraRisultatoGara.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 26, SWT.BOLD)));
		btnRegistraRisultatoGara.setBounds(10, 316, 1134, 67);
		formToolkit.adapt(btnRegistraRisultatoGara, true, true);
		btnRegistraRisultatoGara.setText("REGISTRA");
		
		Label lblMotivoRitiro = new Label(shell6, SWT.NONE);
		lblMotivoRitiro.setText("MOTIVO RITIRO");
		lblMotivoRitiro.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 11, SWT.BOLD)));
		lblMotivoRitiro.setBounds(10, 240, 210, 32);
		formToolkit.adapt(lblMotivoRitiro, true, true);
		
		Label lblPuntiOttenuti = new Label(shell6, SWT.NONE);
		lblPuntiOttenuti.setText("PUNTI OTTENUTI");
		lblPuntiOttenuti.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 11, SWT.BOLD)));
		lblPuntiOttenuti.setBounds(10, 278, 210, 32);
		formToolkit.adapt(lblPuntiOttenuti, true, true);
		
		puntiottenutitxt = new Text(shell6, SWT.BORDER);
		puntiottenutitxt.setBounds(226, 278, 918, 32);
		formToolkit.adapt(puntiottenutitxt, true, true);
		
		Button RitiroCheck = new Button(shell6, SWT.CHECK);
		RitiroCheck.setBounds(226, 202, 918, 32);
		formToolkit.adapt(RitiroCheck, true, true);
		
		
		Combo motivoritirocombo = new Combo(shell6, SWT.READ_ONLY);
		motivoritirocombo.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				selection = motivoritirocombo.getSelectionIndex();
				motivoritirato = motivoritirocombo.getText();
				if(ritirato) {
					if(!codicegaratxt.getText().isEmpty() && !codicevetturatxt.getText().isEmpty() && !puntiottenutitxt.getText().isEmpty() && selection>=0) btnRegistraRisultatoGara.setEnabled(true);
				}
			}
		});
		motivoritirocombo.setEnabled(false);
		motivoritirocombo.setItems(new String[] {"Squalifica", "Guasto meccanico", "Incidente"});
		motivoritirocombo.setBounds(226, 241, 918, 23);
		formToolkit.adapt(motivoritirocombo);
		formToolkit.paintBordersFor(motivoritirocombo);
		
		RitiroCheck.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				ritirato = RitiroCheck.getSelection();
				motivoritirocombo.setEnabled(ritirato);
				if(ritirato) {
					if(!codicegaratxt.getText().isEmpty() && !codicevetturatxt.getText().isEmpty() && !puntiottenutitxt.getText().isEmpty() && selection>=0) btnRegistraRisultatoGara.setEnabled(true);
					if(selection<0) btnRegistraRisultatoGara.setEnabled(false);
				}
			}
		});

		codicegaratxt.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				if(!ritirato) {
					if(!codicegaratxt.getText().isEmpty() && !codicevetturatxt.getText().isEmpty() && !puntiottenutitxt.getText().isEmpty()) btnRegistraRisultatoGara.setEnabled(true);
				}
				if (ritirato) {
					if(!codicegaratxt.getText().isEmpty() && !codicevetturatxt.getText().isEmpty() && !puntiottenutitxt.getText().isEmpty() && selection>=0) btnRegistraRisultatoGara.setEnabled(true);
				}
				if(codicegaratxt.getText().isEmpty()) btnRegistraRisultatoGara.setEnabled(false);
			}
		});
		codicevetturatxt.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				if(!ritirato) {
					if(!codicegaratxt.getText().isEmpty() && !codicevetturatxt.getText().isEmpty() && !puntiottenutitxt.getText().isEmpty()) btnRegistraRisultatoGara.setEnabled(true);
				}
				if (ritirato) {
					if(!codicegaratxt.getText().isEmpty() && !codicevetturatxt.getText().isEmpty() && !puntiottenutitxt.getText().isEmpty() && selection>=0) btnRegistraRisultatoGara.setEnabled(true);
				}
				if(codicevetturatxt.getText().isEmpty()) btnRegistraRisultatoGara.setEnabled(false);
			}
		});
		puntiottenutitxt.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				if(!ritirato) {
					if(!codicegaratxt.getText().isEmpty() && !codicevetturatxt.getText().isEmpty() && !puntiottenutitxt.getText().isEmpty()) btnRegistraRisultatoGara.setEnabled(true);
				}
				if (ritirato) {
					if(!codicegaratxt.getText().isEmpty() && !codicevetturatxt.getText().isEmpty() && !puntiottenutitxt.getText().isEmpty() && selection>=0) btnRegistraRisultatoGara.setEnabled(true);
				}
				if(puntiottenutitxt.getText().isEmpty()) btnRegistraRisultatoGara.setEnabled(false);
			}
		});
		
	}
	/**
	 * @wbp.parser.entryPoint
	 */
	private void createResourceManager() {
		localResourceManager = new LocalResourceManager(JFaceResources.getResources(),shell6);
	}
	private void registraIscrizioneBottoneFunzione(){
	    try {
	    	int controlloquery1;
	        ResultSet rs;
	        PreparedStatement preparedstatement;
	        basedati = new Database(login.databaseName,login.databaseUsername,login.databasePassword);
	        basedati.connect();

	        // Prima query
	        preparedstatement = basedati.getConnection().prepareStatement("SELECT 1 FROM basedidati.iscrizione WHERE codice_gara = ? AND codice_vettura = ?");
	        preparedstatement.setString(1, codicegaratxt.getText());
	        preparedstatement.setString(2, codicevetturatxt.getText());
	        rs = preparedstatement.executeQuery();

	        // Controlla se la query ha restituito almeno una riga
	        if (rs.next()) {
	            // Se la riga esiste, esegui la seconda query
	        	if(ritirato) {
	        		preparedstatement.close();
	        		preparedstatement = basedati.getConnection().prepareStatement("UPDATE basedidati.iscrizione SET punti = ?, motivo_ritiro = ? WHERE codice_gara = ? AND codice_vettura = ?");
		            preparedstatement.setString(1, puntiottenutitxt.getText());
		            preparedstatement.setString(2, motivoritirato);
		            preparedstatement.setString(3, codicegaratxt.getText());
			        preparedstatement.setString(4, codicevetturatxt.getText());
		            controlloquery1 = preparedstatement.executeUpdate();
	        	}
	        	else {
	        		preparedstatement.close();
	        		preparedstatement = basedati.getConnection().prepareStatement("UPDATE basedidati.iscrizione SET punti = ?, motivo_ritiro = NULL WHERE codice_gara = ? AND codice_vettura = ?");
		            preparedstatement.setString(1, puntiottenutitxt.getText());
		            preparedstatement.setString(2, codicegaratxt.getText());
			        preparedstatement.setString(3, codicevetturatxt.getText());
		            controlloquery1 = preparedstatement.executeUpdate();
	        	}
	            if(controlloquery1>0) {
	                successo.main(null);
	            }
	        }
	        else {
	        	fallimento6.main(null);
	        }

	        rs.close();
	        preparedstatement.close();
	        basedati.close();
	    } catch(SQLIntegrityConstraintViolationException e){
	        fallimento6.main(null);
	    } catch(Exception e) {
	    	fallimento4_1.main(null);
	        e.printStackTrace();
	    }
	}
	
}
