import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.SWT;
import org.eclipse.jface.resource.LocalResourceManager;
import org.eclipse.jface.resource.JFaceResources;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLIntegrityConstraintViolationException;

import org.eclipse.jface.resource.FontDescriptor;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;

public class query7 {

	private String pezzo;
	int selection = -1;
	private Database basedati;
	protected static Shell shell7;
	private LocalResourceManager localResourceManager;
	private final FormToolkit formToolkit = new FormToolkit(Display.getDefault());
	private Text codicevetturaverificatxt;

	public static void main(String[] args) {
		try {
			if(shell7 == null || shell7.isDisposed())
			{
				/**
				 * Launch the application.
				 * @param args
				 * @wbp.parser.entryPoint
				 */
				query7 window = new query7();
				window.open();
			}
			else {
				shell7.forceActive();
				shell7.setMinimized(false);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 * @wbp.parser.entryPoint
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell7.open();
		shell7.layout();
		while (!shell7.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 * @wbp.parser.entryPoint
	 */
	protected void createContents() {
		shell7 = new Shell();
		createResourceManager();
		shell7.setImage(null);
		shell7.setSize(1174, 404);
		
		Label lblVerificaComponente = new Label(shell7, SWT.NONE);
		lblVerificaComponente.setAlignment(SWT.CENTER);
		lblVerificaComponente.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 24, SWT.BOLD)));
		lblVerificaComponente.setBounds(10, 10, 1138, 124);
		lblVerificaComponente.setText("VERIFICA COMPONENTE");
		
		Label lblTendina = new Label(shell7, SWT.NONE);
		lblTendina.setText("COMPONENTE DA VERIFICARE");
		lblTendina.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 11, SWT.BOLD)));
		lblTendina.setBounds(10, 178, 352, 32);
		formToolkit.adapt(lblTendina, true, true);
		
		Button btnVerificaComponente = new Button(shell7, SWT.NONE);
		btnVerificaComponente.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				controlloPezzoBottoneFunzione();
			}
		});
		btnVerificaComponente.setEnabled(false);
		btnVerificaComponente.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 26, SWT.BOLD)));
		btnVerificaComponente.setBounds(10, 216, 1138, 139);
		formToolkit.adapt(btnVerificaComponente, true, true);
		btnVerificaComponente.setText("VERIFICA");
		
		codicevetturaverificatxt = new Text(shell7, SWT.BORDER);
		codicevetturaverificatxt.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				if(!codicevetturaverificatxt.getText().isEmpty() && selection>=0) btnVerificaComponente.setEnabled(true);
				if(codicevetturaverificatxt.getText().isEmpty()) btnVerificaComponente.setEnabled(false);
			}
		});
		codicevetturaverificatxt.setBounds(368, 141, 780, 32);
		formToolkit.adapt(codicevetturaverificatxt, true, true);
		
		Combo componentecomboverifica = new Combo(shell7, SWT.READ_ONLY);
		componentecomboverifica.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				selection = componentecomboverifica.getSelectionIndex();
				pezzo = componentecomboverifica.getText();
				if(!codicevetturaverificatxt.getText().isEmpty() && selection>=0) btnVerificaComponente.setEnabled(true);
			}
		});
		componentecomboverifica.setItems(new String[] {"Motore", "Cambio", "Telaio"});
		componentecomboverifica.setBounds(368, 179, 780, 23);
		formToolkit.adapt(componentecomboverifica);
		formToolkit.paintBordersFor(componentecomboverifica);
		
		Label lblCodiceVettura = new Label(shell7, SWT.NONE);
		lblCodiceVettura.setText("CODICE VETTURA");
		lblCodiceVettura.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 11, SWT.BOLD)));
		lblCodiceVettura.setBounds(10, 140, 352, 32);
		formToolkit.adapt(lblCodiceVettura, true, true);
		
		

	}
	/**
	 * @wbp.parser.entryPoint
	 */
	private void createResourceManager() {
		localResourceManager = new LocalResourceManager(JFaceResources.getResources(),shell7);
	}
	private void controlloPezzoBottoneFunzione(){
	    try {
	    	PreparedStatement preparedstatement;
	        basedati = new Database(login.databaseName,login.databaseUsername,login.databasePassword);
	        basedati.connect();

	    	// Prepara la query
	    	preparedstatement = basedati.getConnection().prepareStatement("SELECT 1 FROM basedidati.componente WHERE codice_vettura = ? AND tipo = ?");

	    	// Imposta i parametri
	    	preparedstatement.setString(1, codicevetturaverificatxt.getText());
	    	preparedstatement.setString(2, pezzo);

	    	// Esegui la query
	    	ResultSet rs = preparedstatement.executeQuery();

	    	// Controlla se la query ha restituito almeno una riga
	    	if (rs.next()) {
	    		fallimento7.main(null);
	    	    // Il componente esiste per la vettura
	    	} else {
	    		fallimento7_1.main(null);
	    	    // Il componente non esiste per la vettura
	    	}

	    	// Chiudi il ResultSet e il PreparedStatement
	    	rs.close();
	    	preparedstatement.close();
	    } catch(SQLIntegrityConstraintViolationException e){
	        fallimento7.main(null);
	    } catch(Exception e) {
	    	fallimento4_1.main(null);
	        e.printStackTrace();
	    }
	}
}