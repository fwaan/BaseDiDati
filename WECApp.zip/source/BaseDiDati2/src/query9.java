import javax.swing.*;
import java.awt.*;
import javax.swing.table.DefaultTableModel;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLIntegrityConstraintViolationException;

public class query9 extends JFrame {
    private static final long serialVersionUID = 1L;
    private Database basedati;

    public static void main(String[] args) {
        new query9();
    }
    
    public query9() {
        setLayout(new BorderLayout());

        // Crea un modello di tabella
        DefaultTableModel model = new DefaultTableModel(new String[]{"Codice scuderia", "Nome", "Paese", "Numero finanziamenti"}, 0){
            private static final long serialVersionUID = 2L;
            @Override
            public boolean isCellEditable(int row, int column) {
                // Tutte le celle non sono modificabili
                return false;
            }
        };

        // Crea una tabella con il modello
        JTable table = new JTable(model);

        // Aggiungi la tabella a uno JScrollPane
        add(new JScrollPane(table), BorderLayout.CENTER);
        pack();
        setVisible(false);

        try {
            PreparedStatement preparedstatement;
            basedati = new Database(login.databaseName,login.databaseUsername,login.databasePassword);
            basedati.connect();

            // Prepara la query
            preparedstatement = basedati.getConnection().prepareStatement("SELECT * FROM basedidati.scuderia");

            // Esegui la query
            ResultSet rs = preparedstatement.executeQuery();

            // Controlla se la query ha restituito almeno una riga
            if (rs.next()) {
                setVisible(true);
                do {
                    model.addRow(new Object[]{rs.getString("codice"), rs.getString("nome"), rs.getString("paese"), rs.getString("finanziamenti")});
                } while (rs.next());
            } else {
                fallimento9.main(null);
            }

            // Chiudi il ResultSet e il PreparedStatement
            rs.close();
            preparedstatement.close();
        } catch(SQLIntegrityConstraintViolationException e){
            fallimento9.main(null);
        } catch(Exception e) {
        	fallimento4_1.main(null);
            e.printStackTrace();
        }
    }
}