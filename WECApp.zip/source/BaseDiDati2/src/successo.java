import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.SWT;
import org.eclipse.jface.resource.LocalResourceManager;
import org.eclipse.jface.resource.JFaceResources;
import org.eclipse.jface.resource.FontDescriptor;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Label;

public class successo {

	protected Shell shellsuccesso;
	private LocalResourceManager localResourceManager;
	private Label lblOperazioneAvvenutaCon;

	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			successo window = new successo();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shellsuccesso.open();
		shellsuccesso.layout();
		while (!shellsuccesso.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shellsuccesso = new Shell();
		createResourceManager();
		shellsuccesso.setSize(878, 339);
		
		Button btnNewButton = new Button(shellsuccesso, SWT.NONE);
		btnNewButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				shellsuccesso.close();
			}
		});
		btnNewButton.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 52, SWT.BOLD)));
		btnNewButton.setBounds(10, 150, 842, 140);
		btnNewButton.setText("CHIUDI");
		
		lblOperazioneAvvenutaCon = new Label(shellsuccesso, SWT.NONE);
		lblOperazioneAvvenutaCon.setAlignment(SWT.CENTER);
		lblOperazioneAvvenutaCon.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 24, SWT.BOLD)));
		lblOperazioneAvvenutaCon.setBounds(10, 10, 842, 134);
		lblOperazioneAvvenutaCon.setText("OPERAZIONE AVVENUTA CON SUCCESSO");

	}
	private void createResourceManager() {
		localResourceManager = new LocalResourceManager(JFaceResources.getResources(),shellsuccesso);
	}
}
